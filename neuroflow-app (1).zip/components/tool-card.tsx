"use client"

import { useState } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import type { Tool } from "@/lib/tools-data"
import ToolDetail from "@/components/tool-detail"

interface ToolCardProps {
  toolKey: string
  tool: Tool
  isRecommended: boolean
}

export default function ToolCard({ toolKey, tool, isRecommended }: ToolCardProps) {
  const { selectedSystemTools, addToolToSystem } = useQuiz()
  const [showDetail, setShowDetail] = useState(false)

  const isSelected = selectedSystemTools.has(toolKey)

  const handleAddTool = () => {
    if (!isSelected) {
      addToolToSystem(toolKey)
    }
  }

  return (
    <div
      className={`bg-white p-6 rounded-lg shadow-md border-2 transition-all ${
        isRecommended ? "border-[#84A98C] shadow-lg" : "border-gray-200"
      }`}
    >
      <h4 className="text-lg font-bold text-[#354F52] mb-2">
        {tool.name}
        <span className="inline-block ml-2 px-2 py-1 bg-[#CAD2C5] text-xs font-semibold rounded-full">
          Level {tool.difficultyLevel}
        </span>
      </h4>

      <p className="text-sm mb-4">{tool.description}</p>

      <div className="flex gap-2 mb-4">
        <button
          onClick={() => setShowDetail(!showDetail)}
          className="text-sm text-[#84A98C] font-semibold hover:text-[#52796F]"
        >
          {showDetail ? "Show Less" : "Learn More"}
        </button>

        <button
          onClick={handleAddTool}
          disabled={isSelected}
          className={`text-sm font-semibold ${
            isSelected ? "text-gray-400 cursor-default" : "text-[#84A98C] hover:text-[#52796F]"
          }`}
        >
          {isSelected ? "✓ Added to System" : "+ Add to My System"}
        </button>
      </div>

      {showDetail && <ToolDetail toolKey={toolKey} tool={tool} />}
    </div>
  )
}
