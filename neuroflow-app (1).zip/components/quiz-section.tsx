"use client"

import { useState } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import NeuralAnalysis from "@/components/neural-analysis"
import PreviousSessions from "@/components/previous-sessions"
import { quizData } from "@/lib/quiz-data"

export default function QuizSection() {
  const {
    currentQuestionIndex,
    selectedAnswers,
    userType,
    showResult,
    setCurrentQuestionIndex,
    setSelectedAnswers,
    setUserType,
    setShowResult,
    setShowToolkit,
  } = useQuiz()

  const [showAnalysis, setShowAnalysis] = useState(false)

  const handleOptionSelect = (type: string) => {
    const newAnswers = [...selectedAnswers]
    newAnswers[currentQuestionIndex] = type
    setSelectedAnswers(newAnswers)
  }

  const handleNext = () => {
    if (currentQuestionIndex < quizData.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    } else {
      calculateResult()
    }
  }

  const handleBack = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const calculateResult = () => {
    const scores = { Perfectionist: 0, Avoider: 0, Overwhelmed: 0, ImpulseSeeker: 0 }
    selectedAnswers.forEach((answerType) => {
      if (answerType && scores.hasOwnProperty(answerType)) {
        scores[answerType as keyof typeof scores]++
      }
    })

    let dominantType = "Perfectionist"
    let maxScore = -1
    for (const [type, score] of Object.entries(scores)) {
      if (score > maxScore) {
        maxScore = score
        dominantType = type
      }
    }

    setUserType(dominantType as keyof typeof quizData.results)
    setShowResult(true)
    setShowAnalysis(true)
  }

  const handleShowToolkit = () => {
    setShowToolkit(true)
    document.getElementById("toolkit")?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <section id="diagnose" className="mb-16">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-[#354F52]">Discover Your Procrastination Fingerprint</h2>
        <p className="max-w-2xl mx-auto mt-2">
          Our AI analyzes your patterns to reveal why you procrastinate and how to rewire your system
        </p>
      </div>

      {/* Add Previous Sessions component here */}
      <div className="max-w-2xl mx-auto mb-6">
        <PreviousSessions />
      </div>

      {showResult && userType ? (
        <section id="diagnose" className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-[#354F52]">Discover Your Procrastination Fingerprint</h2>
            <p className="max-w-2xl mx-auto mt-2">
              Our AI analyzes your patterns to reveal why you procrastinate and how to rewire your system
            </p>
          </div>

          <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-xl border-t-4 border-[#84A98C]">
            {quizData.results?.[userType] && (
              <>
                <p className="text-sm font-medium text-[#84A98C] mb-2">YOUR PRIMARY TYPE:</p>
                <h3 className="text-3xl font-bold text-[#354F52] mb-4">
                  {quizData.results[userType].icon} {quizData.results[userType].title}
                </h3>
                <p className="mb-6">{quizData.results[userType].description}</p>
              </>
            )}
            <button
              onClick={handleShowToolkit}
              className="bg-[#84A98C] text-white px-6 py-3 rounded-lg font-semibold hover:bg-[#52796F] transition-colors"
            >
              See My Personalized Toolkit
            </button>
          </div>

          {showAnalysis && <NeuralAnalysis userType={userType} />}
        </section>
      ) : (
        <section id="diagnose" className="mb-16">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-[#354F52]">Discover Your Procrastination Fingerprint</h2>
            <p className="max-w-2xl mx-auto mt-2">
              Our AI analyzes your patterns to reveal why you procrastinate and how to rewire your system
            </p>
          </div>

          <div className="max-w-2xl mx-auto bg-white p-8 rounded-lg shadow-md">
            <h3 className="text-xl font-semibold mb-6">{quizData.questions[currentQuestionIndex].question}</h3>

            <div className="space-y-4 mb-6">
              {quizData.questions[currentQuestionIndex].options.map((option, index) => (
                <div
                  key={index}
                  onClick={() => handleOptionSelect(option.type)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all hover:border-[#84A98C] hover:-translate-y-1 ${
                    selectedAnswers[currentQuestionIndex] === option.type
                      ? "border-[#84A98C] bg-green-50"
                      : "border-gray-200"
                  }`}
                >
                  <p className="font-medium">{option.text}</p>
                </div>
              ))}
            </div>

            <div className="flex justify-between">
              <button
                onClick={handleBack}
                className={`px-6 py-2 rounded-lg font-semibold ${
                  currentQuestionIndex === 0 ? "invisible" : "bg-gray-200 text-[#354F52] hover:bg-gray-300"
                }`}
              >
                Back
              </button>
              <button
                onClick={handleNext}
                disabled={!selectedAnswers[currentQuestionIndex]}
                className={`px-6 py-2 rounded-lg font-semibold ${
                  selectedAnswers[currentQuestionIndex]
                    ? "bg-[#84A98C] text-white hover:bg-[#52796F]"
                    : "bg-gray-200 text-gray-400 cursor-not-allowed"
                }`}
              >
                {currentQuestionIndex === quizData.questions.length - 1 ? "Get Results" : "Next"}
              </button>
            </div>
          </div>
        </section>
      )}
    </section>
  )
}
