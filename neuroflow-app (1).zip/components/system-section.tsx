"use client"

import { useQuiz } from "@/contexts/quiz-context"
import PremiumProductivityOS from "@/components/premium-productivity-os"

export default function SystemSection() {
  const { showToolkit, isPremiumUnlocked } = useQuiz()

  if (!showToolkit) {
    return null
  }

  return (
    <section id="system" className="mb-16">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-[#354F52]">Your Anti-Procrastination OS</h2>
        <p className="max-w-2xl mx-auto mt-2">
          {isPremiumUnlocked
            ? "Complete productivity operating system with integrated neural rewiring"
            : "Track progress and prevent relapses with neuroscience-backed systems"}
        </p>
      </div>

      {/* Premium ProductivityOS Integration */}
      <PremiumProductivityOS />
    </section>
  )
}
