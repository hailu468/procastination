"use client"

import { useState, useEffect } from "react"
import type { Tool } from "@/lib/tools-data"
import { useToast } from "@/hooks/use-toast"
import { callGeminiAPI } from "@/lib/gemini-api"

interface ToolDetailProps {
  toolKey: string
  tool: Tool
}

export default function ToolDetail({ toolKey, tool }: ToolDetailProps) {
  const { showToast } = useToast()
  const [currentLevel, setCurrentLevel] = useState(1)
  const [timerActive, setTimerActive] = useState(false)
  const [timeLeft, setTimeLeft] = useState(0)
  const [emotionInput, setEmotionInput] = useState("")
  const [emotionAnalysis, setEmotionAnalysis] = useState<{ insight: string; action: string } | null>(null)

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (timerActive && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft((time) => time - 1)
      }, 1000)
    } else if (timeLeft === 0 && timerActive) {
      setTimerActive(false)
      showToast("Timer completed!")
    }
    return () => clearInterval(interval)
  }, [timerActive, timeLeft, showToast])

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const startTimer = (duration: number) => {
    setTimeLeft(duration)
    setTimerActive(true)
  }

  const handleSuccess = () => {
    showToast("Great job! Challenge completed.")
    if (tool.challenges && currentLevel < tool.challenges.length) {
      setCurrentLevel((prev) => prev + 1)
    }
  }

  const handleSkip = () => {
    showToast("No worries, try again later.", true)
  }

  const analyzeEmotion = async () => {
    if (!emotionInput.trim()) return

    const promptInsight = `Analyze the following user's emotional description and provide a brief, empathetic psychological insight (1-2 sentences) into what they might be feeling or experiencing. Emotional description: "${emotionInput}"`

    const insight = await callGeminiAPI(promptInsight)

    if (insight) {
      const promptAction = `Based on the emotional description: "${emotionInput}" and the insight: "${insight}", suggest one small, actionable coping mechanism or next step to address this emotion. Be concise.`
      const action = await callGeminiAPI(promptAction)

      setEmotionAnalysis({
        insight: insight || "Could not analyze emotion.",
        action: action || "Could not suggest an action.",
      })
    }
  }

  const renderToolSpecificContent = () => {
    switch (toolKey) {
      case "uglyDraft":
      case "tinyStarts":
        const challenge = tool.challenges?.[currentLevel - 1] || tool.challenges?.[0] || "Complete the task"
        return (
          <div className="p-4 bg-gray-50 rounded-md">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium">Current Challenge:</span>
              <span className="px-2 py-1 bg-[#CAD2C5] text-xs font-semibold rounded-full">Level {currentLevel}</span>
            </div>
            <p className="text-sm mb-3">{challenge}</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleSuccess}
                className="px-4 py-2 bg-gray-200 text-[#354F52] rounded-lg text-sm hover:bg-gray-300"
              >
                Completed
              </button>
              <button
                onClick={handleSkip}
                className="px-4 py-2 bg-gray-200 text-[#354F52] rounded-lg text-sm hover:bg-gray-300"
              >
                Skipped
              </button>
            </div>
          </div>
        )

      case "twoMinBridge":
        return (
          <div className="p-4 bg-gray-50 rounded-md">
            <div className="flex justify-between items-center mb-2">
              <span className="font-medium">Current Challenge:</span>
              <span className="px-2 py-1 bg-[#CAD2C5] text-xs font-semibold rounded-full">Level {currentLevel}</span>
            </div>
            <p className="text-sm mb-3">Work for 2 minutes</p>
            {!timerActive ? (
              <button
                onClick={() => startTimer(120)}
                className="w-full px-4 py-2 bg-[#84A98C] text-white rounded-lg text-sm hover:bg-[#52796F]"
              >
                Start Timer
              </button>
            ) : (
              <div className="text-center">
                <div className="text-2xl font-bold my-3">{formatTime(timeLeft)}</div>
                <button
                  onClick={() => setTimerActive(false)}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600"
                >
                  Stop Timer
                </button>
              </div>
            )}
          </div>
        )

      case "focusSprints":
        return (
          <div className="p-4 bg-gray-50 rounded-md">
            {!timerActive ? (
              <button
                onClick={() => startTimer(1500)} // 25 minutes
                className="w-full px-4 py-2 bg-[#84A98C] text-white rounded-lg text-sm hover:bg-[#52796F]"
              >
                Start 25-Minute Sprint
              </button>
            ) : (
              <div className="text-center">
                <div className="text-2xl font-bold my-3">{formatTime(timeLeft)}</div>
                <button
                  onClick={() => setTimerActive(false)}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm hover:bg-red-600"
                >
                  Stop Sprint
                </button>
              </div>
            )}
            {timeLeft === 0 && !timerActive && (
              <div className="p-3 bg-green-50 rounded-md text-sm text-center mt-3">
                Sprint complete! Take a 5-minute break.
              </div>
            )}
          </div>
        )

      case "nameEmotion":
        return (
          <div className="p-4 bg-gray-50 rounded-md">
            <textarea
              value={emotionInput}
              onChange={(e) => setEmotionInput(e.target.value)}
              placeholder="Describe what you're avoiding..."
              className="w-full p-3 border rounded-md text-sm mb-3 h-20"
            />
            {emotionAnalysis && (
              <div className="text-sm p-3 bg-blue-50 rounded-md mb-3">
                <div className="font-semibold">AI Analysis:</div>
                <div className="mt-1">{emotionAnalysis.insight}</div>
                <div className="font-semibold mt-2">Actionable Step:</div>
                <div className="mt-1">{emotionAnalysis.action}</div>
              </div>
            )}
            <button
              onClick={analyzeEmotion}
              className="w-full px-4 py-2 bg-[#84A98C] text-white rounded-lg text-sm hover:bg-[#52796F]"
            >
              Analyze Emotion
            </button>
          </div>
        )

      default:
        return (
          <div className="p-4 bg-gray-50 rounded-md">
            <p className="text-sm text-gray-600">Interactive features for this tool coming soon!</p>
          </div>
        )
    }
  }

  return <div className="mt-4 border-t pt-4">{renderToolSpecificContent()}</div>
}
