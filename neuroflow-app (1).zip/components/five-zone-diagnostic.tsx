"use client"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

const FIVE_ZONE_DELAYS = [
  {
    zone: "Mental Zone",
    trigger: "I'm bad at this",
    description: "Negative self-talk and fear of judgment",
    questions: ["What if I do it wrong and fail?", "I'm not ready for this", "I don't know enough"],
  },
  {
    zone: "Emotional Zone",
    trigger: "This feels awful",
    description: "Physical dread and discomfort avoidance",
    questions: ["This feels too overwhelming", "I hate doing this", "It makes me anxious"],
  },
  {
    zone: "Action Zone",
    trigger: "Where do I start?",
    description: "Paralysis from unclear next steps",
    questions: ["I don't know where to begin", "There are too many options", "What's the first step?"],
  },
  {
    zone: "Structural Zone",
    trigger: "Too many distractions",
    description: "Environment sabotaging focus",
    questions: ["My phone keeps buzzing", "Too many tabs open", "Workspace is cluttered"],
  },
  {
    zone: "Recovery Zone",
    trigger: "I blew it",
    description: "Shame spirals after setbacks",
    questions: ["I missed a day, week is ruined", "I'm a failure", "Why bother continuing?"],
  },
]

export default function FiveZoneDiagnostic() {
  const [selectedZone, setSelectedZone] = useState<string>("")
  const [currentTask, setCurrentTask] = useState("")
  const [diagnosticResults, setDiagnosticResults] = useState<any>(null)
  const { showToast } = useToast()

  const runDiagnostic = () => {
    if (!currentTask.trim() || !selectedZone) {
      showToast("Please enter a task and select your primary delay zone", true)
      return
    }

    const zone = FIVE_ZONE_DELAYS.find((z) => z.zone === selectedZone)
    const results = {
      task: currentTask,
      primaryZone: zone,
      recommendation: getRecommendation(selectedZone),
      timestamp: new Date().toISOString(),
    }

    setDiagnosticResults(results)
    showToast("5-Zone Diagnostic complete!")
  }

  const getRecommendation = (zone: string) => {
    const recommendations = {
      "Mental Zone":
        "Use the Reframe Script: 'This is practice, not a final performance.' Start with a 2-minute chaos draft.",
      "Emotional Zone":
        "Name the specific emotion you're avoiding. Use Safe Starts - break into micro-actions that feel harmless.",
      "Action Zone": "Apply the 2-Minute Start rule. Identify the absolute smallest first step and set a timer.",
      "Structural Zone": "Friction Engineering: Block one distraction, ease one task. Phone in drawer, work file open.",
      "Recovery Zone": "Execute the 3-Minute Reset: Breathe, reframe as 'just data', do one tiny action now.",
    }
    return recommendations[zone] || "Focus on identifying your specific trigger pattern."
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <h3 className="text-2xl font-bold text-[#354F52] mb-4 flex items-center">
        <i className="fas fa-search text-[#84A98C] mr-3"></i>
        5-Zone Delay Diagnostic
      </h3>
      <p className="text-gray-600 mb-6">
        Identify which of the 5 delay zones is sabotaging you right now. This isn't about willpower - it's about
        precision targeting.
      </p>

      <div className="space-y-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">What task are you avoiding right now?</label>
          <input
            type="text"
            value={currentTask}
            onChange={(e) => setCurrentTask(e.target.value)}
            placeholder="e.g., Writing the quarterly report"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Which delay zone resonates most with your current struggle?
          </label>
          <div className="space-y-3">
            {FIVE_ZONE_DELAYS.map((zone) => (
              <label
                key={zone.zone}
                className={`flex items-start p-4 border-2 rounded-lg cursor-pointer transition-all ${
                  selectedZone === zone.zone
                    ? "border-[#84A98C] bg-green-50 shadow-md"
                    : "border-gray-200 hover:border-[#84A98C]"
                }`}
              >
                <input
                  type="radio"
                  name="delayZone"
                  value={zone.zone}
                  checked={selectedZone === zone.zone}
                  onChange={(e) => setSelectedZone(e.target.value)}
                  className="form-radio h-5 w-5 text-[#84A98C] mt-1"
                />
                <div className="ml-3">
                  <div className="font-semibold text-[#354F52]">{zone.zone}</div>
                  <div className="text-sm text-gray-600 mb-1">"{zone.trigger}"</div>
                  <div className="text-sm text-gray-500">{zone.description}</div>
                </div>
              </label>
            ))}
          </div>
        </div>
      </div>

      <button
        onClick={runDiagnostic}
        className="w-full bg-[#84A98C] hover:bg-[#52796F] text-white font-semibold py-3 px-6 rounded-lg transition-colors"
      >
        <i className="fas fa-microscope mr-2"></i>
        Run 5-Zone Diagnostic
      </button>

      {diagnosticResults && (
        <div className="mt-6 p-4 bg-blue-50 border-l-4 border-[#84A98C] rounded-lg">
          <h4 className="font-bold text-[#354F52] mb-2">Diagnostic Results</h4>
          <p className="text-sm text-gray-700 mb-2">
            <strong>Task:</strong> {diagnosticResults.task}
          </p>
          <p className="text-sm text-gray-700 mb-2">
            <strong>Primary Delay Zone:</strong> {diagnosticResults.primaryZone.zone}
          </p>
          <p className="text-sm text-gray-700 mb-3">
            <strong>Targeted Solution:</strong> {diagnosticResults.recommendation}
          </p>
          <div className="text-xs text-gray-500">
            Diagnosed: {new Date(diagnosticResults.timestamp).toLocaleString()}
          </div>
        </div>
      )}
    </div>
  )
}
