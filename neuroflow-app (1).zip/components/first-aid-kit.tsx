"use client"

import { useState } from "react"
import { useToast } from "@/hooks/use-toast"

const FIRST_AID_TOOLS = [
  {
    category: "Mindset",
    tool: "Name the Emotion",
    when: "When you feel that familiar dread or overwhelm",
    action: "Ask: 'What specific feeling am I trying to avoid right now?'",
    icon: "brain",
    color: "bg-purple-500",
  },
  {
    category: "Mindset",
    tool: "The Reset Ritual",
    when: "Immediately after a slip-up or self-criticism",
    action: "Breathe for 10 seconds. Say, 'This is just feedback.' Do a 2-minute action.",
    icon: "sync-alt",
    color: "bg-red-500",
  },
  {
    category: "Behavior",
    tool: "The 2-Minute Start",
    when: "When you can't bring yourself to begin a task",
    action: "Identify the absolute smallest first step. Set a timer for 2 minutes and go.",
    icon: "play",
    color: "bg-green-500",
  },
  {
    category: "Behavior",
    tool: "The Time Anchor",
    when: "When your day feels chaotic and unstructured",
    action: "Open your calendar and book one 25-minute task for tomorrow.",
    icon: "anchor",
    color: "bg-blue-500",
  },
  {
    category: "Environment",
    tool: "The Friction Fix",
    when: "When distractions keep winning the battle for attention",
    action: "Block one distraction (phone in drawer). Ease one task (open the file).",
    icon: "cog",
    color: "bg-orange-500",
  },
]

export default function FirstAidKit() {
  const [selectedTool, setSelectedTool] = useState<any>(null)
  const [deployedTools, setDeployedTools] = useState<string[]>([])
  const { showToast } = useToast()

  const deployTool = (tool: any) => {
    setDeployedTools((prev) => [...prev, tool.tool])
    showToast(`${tool.tool} deployed! Take action now.`)

    // Auto-clear after 60 seconds
    setTimeout(() => {
      setDeployedTools((prev) => prev.filter((t) => t !== tool.tool))
    }, 60000)
  }

  const isDeployed = (toolName: string) => deployedTools.includes(toolName)

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <h3 className="text-2xl font-bold text-[#354F52] mb-4 flex items-center">
        <i className="fas fa-first-aid text-red-500 mr-3"></i>
        Procrastination First-Aid Kit
      </h3>
      <p className="text-gray-600 mb-6">
        For immediate deployment within 60 seconds of feeling stuck. Choose your emergency intervention:
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        {FIRST_AID_TOOLS.map((tool, index) => (
          <div
            key={index}
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
              selectedTool?.tool === tool.tool
                ? "border-[#84A98C] bg-green-50 shadow-md"
                : "border-gray-200 hover:border-[#84A98C]"
            } ${isDeployed(tool.tool) ? "ring-2 ring-yellow-400 bg-yellow-50" : ""}`}
            onClick={() => setSelectedTool(tool)}
          >
            <div className={`w-12 h-12 ${tool.color} rounded-full flex items-center justify-center mb-3`}>
              <i className={`fas fa-${tool.icon} text-white text-lg`}></i>
            </div>
            <h4 className="font-bold text-[#354F52] mb-2">{tool.tool}</h4>
            <p className="text-sm text-gray-600 mb-2">{tool.category}</p>
            <p className="text-xs text-gray-500">{tool.when}</p>
            {isDeployed(tool.tool) && (
              <div className="mt-2 text-xs font-semibold text-yellow-700">🚨 DEPLOYED - Take action now!</div>
            )}
          </div>
        ))}
      </div>

      {selectedTool && (
        <div className="p-4 bg-gray-50 border-l-4 border-[#84A98C] rounded-lg mb-4">
          <h4 className="font-bold text-[#354F52] mb-2">{selectedTool.tool}</h4>
          <p className="text-sm text-gray-700 mb-2">
            <strong>When to use:</strong> {selectedTool.when}
          </p>
          <p className="text-sm text-gray-700 mb-4">
            <strong>60-Second Action:</strong> {selectedTool.action}
          </p>
          <button
            onClick={() => deployTool(selectedTool)}
            disabled={isDeployed(selectedTool.tool)}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              isDeployed(selectedTool.tool)
                ? "bg-gray-400 text-gray-600 cursor-not-allowed"
                : "bg-red-500 hover:bg-red-600 text-white"
            }`}
          >
            {isDeployed(selectedTool.tool) ? "Deployed!" : "Deploy Emergency Tool"}
          </button>
        </div>
      )}

      <div className="text-center">
        <p className="text-sm text-gray-500 italic">
          Emergency tools auto-clear after 60 seconds. The goal is immediate action, not prolonged planning.
        </p>
      </div>
    </div>
  )
}
