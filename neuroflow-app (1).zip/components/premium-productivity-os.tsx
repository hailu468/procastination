"use client"

import { useState, useRef, useEffect } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { useToast } from "@/hooks/use-toast"
import { callGeminiAPI } from "@/lib/gemini-api"
import FiveZoneDiagnostic from "@/components/five-zone-diagnostic"
import FirstAidKit from "@/components/first-aid-kit"
import TwoMinuteBridge from "@/components/two-minute-bridge"
import CoreThreeSelector from "@/components/core-three-selector"
import EnhancedSevenDayProgram from "@/components/enhanced-seven-day-program"

interface ScheduleBlock {
  id: string
  activityName: string
  startTime: string
  duration: number
  progress: number
  type: string
  recurrence: string
  youtubeUrl?: string
  subtasks?: string
  date: string
  createdAt: string
  updatedAt: string
  actualStartTime?: string
  actualEndTime?: string
  difficultyRating?: number
  energyLevel?: number
  distractionCount?: number
  zoneDelay?: string
  coreToolUsed?: string
}

interface Distraction {
  id: string
  note: string
  time: string
  date: string
  createdAt: string
  updatedAt: string
  trigger?: string
  intensity?: number
  duration?: number
  zoneCategory?: string
  recoveryAction?: string
}

interface Task {
  id: string
  name: string
  completed: boolean
  createdAt: string
  updatedAt: string
  priority: "low" | "medium" | "high" | "urgent"
  estimatedTime?: number
  actualTime?: number
  category?: string
  procrastinationTrigger?: string
  coreToolAssigned?: string
  bridgeSessionsUsed?: number
}

interface Habit {
  id: string
  name: string
  streak: number
  lastCompleted?: string
  target: number
  frequency: "daily" | "weekly"
  category: string
  linkedTool?: string
  dayProgramIntegration?: number
}

interface ProcrastinationEvent {
  id: string
  task: string
  trigger: string
  emotion: string
  strategy: string
  effectiveness: number
  timestamp: string
  date: string
  zoneIdentified?: string
  toolDeployed?: string
  bridgeUsed?: boolean
  recoveryTime?: number
}

interface DiagnosticResult {
  id: string
  task: string
  primaryZone: any
  recommendation: string
  timestamp: string
  implemented?: boolean
  effectiveness?: number
  linkedTasks?: string[]
}

interface FirstAidDeployment {
  id: string
  tool: string
  timestamp: string
  context: string
  outcome?: string
  followUpAction?: string
}

interface BridgeSession {
  id: string
  task: string
  duration: number
  completed: boolean
  timestamp: string
  momentum?: boolean
  nextAction?: string
}

interface CoreThreeBlueprint {
  id: string
  archetype: string
  coreTools: any[]
  deploymentStrategy: string
  createdAt: string
  weeklyUsage?: { [key: string]: number }
  effectiveness?: number
}

const BLOCK_TYPES = {
  Fixed: { color: "bg-red-500", name: "Fixed", optimal: 25 },
  Flex: { color: "bg-[#84A98C]", name: "Deep Work", optimal: 40 },
  Buffer: { color: "bg-yellow-500", name: "Buffer Time", optimal: 10 },
  Review: { color: "bg-purple-500", name: "Review", optimal: 5 },
  Learning: { color: "bg-[#52796F]", name: "Learning", optimal: 10 },
  Health: { color: "bg-teal-500", name: "Health", optimal: 10 },
}

const ENERGY_LEVELS = [
  { level: "Low", color: "bg-[#CAD2C5]", height: "h-1/4" },
  { level: "Medium", color: "bg-[#84A98C]", height: "h-2/4" },
  { level: "Peak", color: "bg-[#52796F]", height: "h-full" },
  { level: "High", color: "bg-[#354F52]", height: "h-3/4" },
  { level: "Medium", color: "bg-[#84A98C]", height: "h-2/4" },
  { level: "Low", color: "bg-[#CAD2C5]", height: "h-1/4" },
  { level: "Medium", color: "bg-[#84A98C]", height: "h-2/4" },
  { level: "Low", color: "bg-[#CAD2C5]", height: "h-1/4" },
]

const PROCRASTINATION_TRIGGERS = [
  "Task too overwhelming",
  "Perfectionism",
  "Fear of failure",
  "Lack of clarity",
  "Boring/uninteresting",
  "Too difficult",
  "No immediate reward",
  "Distractions",
  "Low energy",
  "Poor environment",
  "Unclear deadline",
  "Lack of motivation",
]

const FIVE_ZONE_DELAYS = [
  { zone: "Mental Zone", trigger: "I'm bad at this", description: "Negative self-talk" },
  { zone: "Emotional Zone", trigger: "This feels awful", description: "Physical dread" },
  { zone: "Action Zone", trigger: "Where do I start?", description: "Paralysis" },
  { zone: "Structural Zone", trigger: "Too many distractions", description: "Environment issues" },
  { zone: "Recovery Zone", trigger: "I blew it", description: "Shame spirals" },
]

export default function PremiumProductivityOS() {
  const { isPremiumUnlocked, selectedSystemTools, userType } = useQuiz()
  const { showToast } = useToast()

  // Integrated State Management
  const [schedule, setSchedule] = useState<ScheduleBlock[]>([])
  const [distractions, setDistractions] = useState<Distraction[]>([])
  const [tasks, setTasks] = useState<Task[]>([])
  const [habits, setHabits] = useState<Habit[]>([])
  const [procrastinationLog, setProcrastinationLog] = useState<ProcrastinationEvent[]>([])
  const [diagnosticResults, setDiagnosticResults] = useState<DiagnosticResult[]>([])
  const [firstAidDeployments, setFirstAidDeployments] = useState<FirstAidDeployment[]>([])
  const [bridgeSessions, setBridgeSessions] = useState<BridgeSession[]>([])
  const [coreThreeBlueprint, setCoreThreeBlueprint] = useState<CoreThreeBlueprint | null>(null)
  const [activeTab, setActiveTab] = useState("dashboard")
  const [currentDate] = useState(new Date())

  // UI State
  const [productivityScore, setProductivityScore] = useState(0)
  const [focusSession, setFocusSession] = useState<any>(null)
  const [environmentCheck, setEnvironmentCheck] = useState<any>({})
  const [frictionEngineering, setFrictionEngineering] = useState({
    phone: true,
    notifications: true,
    socialMedia: true,
    email: true,
  })

  // Modal states
  const [showBlockModal, setShowBlockModal] = useState(false)
  const [showDistractionModal, setShowDistractionModal] = useState(false)
  const [showProcrastinationModal, setShowProcrastinationModal] = useState(false)
  const [showEnvironmentModal, setShowEnvironmentModal] = useState(false)
  const [editingBlock, setEditingBlock] = useState<ScheduleBlock | null>(null)

  // Form states
  const [blockForm, setBlockForm] = useState({
    activityName: "",
    startTime: "09:00",
    duration: 60,
    progress: 0,
    type: "Flex",
    recurrence: "none",
    youtubeUrl: "",
    subtasks: "",
    zoneDelay: "",
    coreToolUsed: "",
  })

  const [distractionForm, setDistractionForm] = useState({
    note: "",
    time: "",
    trigger: "",
    intensity: 5,
    duration: 5,
    zoneCategory: "",
    recoveryAction: "",
  })

  const [procrastinationForm, setProcrastinationForm] = useState({
    task: "",
    trigger: "",
    emotion: "",
    strategy: "",
    effectiveness: 5,
    zoneIdentified: "",
    toolDeployed: "",
    bridgeUsed: false,
  })

  const [newTaskName, setNewTaskName] = useState("")
  const [newTaskPriority, setNewTaskPriority] = useState<"low" | "medium" | "high" | "urgent">("medium")
  const [aiOutput, setAiOutput] = useState("")

  // Pomodoro state
  const [pomodoro, setPomodoro] = useState({
    timeLeft: 25 * 60,
    isRunning: false,
    mode: "work" as "work" | "break",
    workSessionsCompleted: 0,
    currentTask: "",
    linkedTool: "",
  })

  // Progress tracking state
  const [consistency, setConsistency] = useState(30)
  const [mastery, setMastery] = useState(45)
  const [resilience, setResilience] = useState(60)

  const pomodoroInterval = useRef<NodeJS.Timeout | null>(null)

  // Initialize integrated habits
  useEffect(() => {
    if (habits.length === 0) {
      setHabits([
        {
          id: "1",
          name: "Morning 5-Zone Check",
          streak: 0,
          target: 1,
          frequency: "daily",
          category: "Diagnostic",
          linkedTool: "5-Zone Diagnostic",
        },
        {
          id: "2",
          name: "Evening System Review",
          streak: 0,
          target: 1,
          frequency: "daily",
          category: "Reflection",
          linkedTool: "Core 3 Selector",
        },
        {
          id: "3",
          name: "2-Minute Bridge Practice",
          streak: 0,
          target: 3,
          frequency: "daily",
          category: "Action",
          linkedTool: "2-Minute Bridge",
        },
        {
          id: "4",
          name: "Weekly Neural Rewiring",
          streak: 0,
          target: 1,
          frequency: "weekly",
          category: "Development",
          dayProgramIntegration: 7,
        },
      ])
    }
  }, [habits.length])

  // Integrated productivity score calculation
  useEffect(() => {
    const completedTasks = tasks.filter((t) => t.completed).length
    const totalTasks = tasks.length
    const completedBlocks = schedule.filter((b) => b.progress === 100).length
    const totalBlocks = schedule.length
    const avgHabitStreak = habits.reduce((sum, h) => sum + h.streak, 0) / (habits.length || 1)
    const diagnosticImplementation =
      diagnosticResults.filter((d) => d.implemented).length / (diagnosticResults.length || 1)
    const bridgeSuccessRate = bridgeSessions.filter((b) => b.completed).length / (bridgeSessions.length || 1)
    const coreToolUsage = coreThreeBlueprint?.effectiveness || 0

    const score = Math.round(
      (completedTasks / (totalTasks || 1)) * 20 +
        (completedBlocks / (totalBlocks || 1)) * 25 +
        Math.min(avgHabitStreak / 7, 1) * 20 +
        diagnosticImplementation * 15 +
        bridgeSuccessRate * 10 +
        (coreToolUsage / 100) * 10,
    )
    setProductivityScore(score)
  }, [tasks, schedule, habits, diagnosticResults, bridgeSessions, coreThreeBlueprint])

  if (!isPremiumUnlocked) {
    return (
      <div className="p-8 text-center bg-white rounded-lg shadow-md border border-gray-200">
        <div className="mb-6">
          <i className="fas fa-brain text-6xl text-[#84A98C] mb-4"></i>
          <h3 className="text-3xl font-bold text-[#354F52] mb-4">Premium ProductivityOS</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            Unlock the complete "You're Not Lazy" methodology with integrated procrastination-solving features that work
            together as a unified system.
          </p>
        </div>

        <div className="mb-8">
          <h4 className="text-xl font-bold text-[#354F52] mb-4">Integrated Anti-Procrastination Ecosystem</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6 text-sm">
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
              <i className="fas fa-search text-3xl text-[#84A98C] mb-3"></i>
              <div className="font-bold text-[#354F52] mb-1">Smart Diagnostics</div>
              <div className="text-gray-600 text-xs mb-2">Auto-assigns tools based on patterns</div>
              <div className="text-blue-600 text-xs">Links delays to specific interventions</div>
            </div>

            <div className="bg-gradient-to-br from-red-50 to-pink-50 p-4 rounded-lg border border-red-200">
              <i className="fas fa-first-aid text-3xl text-red-500 mb-3"></i>
              <div className="font-bold text-[#354F52] mb-1">Contextual Interventions</div>
              <div className="text-gray-600 text-xs mb-2">Deploys based on current situation</div>
              <div className="text-red-600 text-xs">Tracks effectiveness and adapts</div>
            </div>

            <div className="bg-gradient-to-br from-green-50 to-emerald-50 p-4 rounded-lg border border-green-200">
              <i className="fas fa-bridge text-3xl text-[#84A98C] mb-3"></i>
              <div className="font-bold text-[#354F52] mb-1">Momentum Building</div>
              <div className="text-gray-600 text-xs mb-2">Bridges feed into larger tasks</div>
              <div className="text-green-600 text-xs">Creates compound progress</div>
            </div>

            <div className="bg-gradient-to-br from-purple-50 to-violet-50 p-4 rounded-lg border border-purple-200">
              <i className="fas fa-tools text-3xl text-[#84A98C] mb-3"></i>
              <div className="font-bold text-[#354F52] mb-1">Adaptive System</div>
              <div className="text-gray-600 text-xs mb-2">Core 3 evolves with usage data</div>
              <div className="text-purple-600 text-xs">Optimizes based on effectiveness</div>
            </div>

            <div className="bg-gradient-to-br from-orange-50 to-amber-50 p-4 rounded-lg border border-orange-200">
              <i className="fas fa-calendar-week text-3xl text-[#84A98C] mb-3"></i>
              <div className="font-bold text-[#354F52] mb-1">Progressive Development</div>
              <div className="text-gray-600 text-xs mb-2">7-day program integrates all tools</div>
              <div className="text-orange-600 text-xs">Builds comprehensive mastery</div>
            </div>

            <div className="bg-gradient-to-br from-teal-50 to-cyan-50 p-4 rounded-lg border border-teal-200">
              <i className="fas fa-chart-line text-3xl text-[#84A98C] mb-3"></i>
              <div className="font-bold text-[#354F52] mb-1">Unified Analytics</div>
              <div className="text-gray-600 text-xs mb-2">Cross-system insights and patterns</div>
              <div className="text-teal-600 text-xs">Predictive recommendations</div>
            </div>
          </div>
        </div>

        <div className="bg-gradient-to-r from-[#84A98C] to-[#52796F] text-white p-4 rounded-lg mb-4">
          <p className="font-semibold mb-2">🧠 Complete Integrated Methodology</p>
          <p className="text-sm opacity-90">
            All tools work together - diagnostics inform interventions, bridges build momentum, and your Core 3 adapts
            based on real usage data
          </p>
        </div>

        <p className="text-sm text-gray-500">
          Upgrade to Premium for the complete integrated anti-procrastination system
        </p>
      </div>
    )
  }

  // Integrated Functions

  // Smart Task Creation with Auto-Assignment
  const addTask = () => {
    if (!newTaskName.trim()) return

    // Auto-detect potential procrastination triggers
    const triggerKeywords = {
      perfectionism: ["perfect", "best", "ideal", "flawless"],
      overwhelm: ["big", "huge", "complex", "everything"],
      unclear: ["figure out", "research", "explore", "understand"],
      boring: ["boring", "tedious", "routine", "mundane"],
    }

    let detectedTrigger = ""
    let suggestedTool = ""

    for (const [trigger, keywords] of Object.entries(triggerKeywords)) {
      if (keywords.some((keyword) => newTaskName.toLowerCase().includes(keyword))) {
        detectedTrigger = trigger
        break
      }
    }

    // Suggest core tool based on user type and detected trigger
    if (coreThreeBlueprint) {
      suggestedTool = coreThreeBlueprint.coreTools[0]?.name || ""
    }

    const newTask: Task = {
      id: Date.now().toString(),
      name: newTaskName.trim(),
      completed: false,
      priority: newTaskPriority,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      procrastinationTrigger: detectedTrigger,
      coreToolAssigned: suggestedTool,
      bridgeSessionsUsed: 0,
    }

    setTasks((prev) => [...prev, newTask])
    setNewTaskName("")

    if (detectedTrigger) {
      showToast(
        `Task added! Detected trigger: ${detectedTrigger}. Consider using ${suggestedTool || "your Core 3 tools"}.`,
      )
    } else {
      showToast("Task added with smart analysis!")
    }
  }

  // Integrated Procrastination Logging
  const logProcrastinationEvent = () => {
    const newEvent: ProcrastinationEvent = {
      id: Date.now().toString(),
      ...procrastinationForm,
      timestamp: new Date().toISOString(),
      date: currentDate.toISOString().split("T")[0],
    }
    setProcrastinationLog((prev) => [...prev, newEvent])

    // Auto-suggest diagnostic if pattern detected
    const recentEvents = procrastinationLog.slice(-3)
    const commonTrigger = recentEvents.find((e) => e.trigger === newEvent.trigger)

    if (commonTrigger) {
      showToast("Pattern detected! Consider running a 5-Zone Diagnostic.", false)
      // Auto-schedule diagnostic
      setTimeout(() => {
        setActiveTab("advanced-system")
      }, 2000)
    }

    // Auto-deploy first aid if high intensity
    if (procrastinationForm.effectiveness < 3) {
      const firstAidDeployment: FirstAidDeployment = {
        id: Date.now().toString(),
        tool: "Auto-deployed based on low effectiveness",
        timestamp: new Date().toISOString(),
        context: `Low effectiveness (${procrastinationForm.effectiveness}/10) for ${procrastinationForm.task}`,
      }
      setFirstAidDeployments((prev) => [...prev, firstAidDeployment])
      showToast("First Aid Kit auto-deployed due to low strategy effectiveness!")
    }

    setShowProcrastinationModal(false)
    setProcrastinationForm({
      task: "",
      trigger: "",
      emotion: "",
      strategy: "",
      effectiveness: 5,
      zoneIdentified: "",
      toolDeployed: "",
      bridgeUsed: false,
    })

    // 3-Step Reset Ritual with integration
    executeResetRitual(newEvent.task)
  }

  // Integrated Reset Ritual
  const executeResetRitual = (taskName: string) => {
    showToast("Executing 3-Step Reset Ritual...")

    // Step 1: Pause (10 seconds)
    setTimeout(() => {
      showToast("Step 1: Breathe and pause - this is just feedback, not failure")
    }, 1000)

    // Step 2: Reframe (auto-reframe based on user type)
    setTimeout(() => {
      const reframes = {
        Perfectionist: "Progress over perfection - done is better than perfect",
        Avoider: "This is practice, not performance - no judgment here",
        Overwhelmed: "One tiny step at a time - break it down further",
        ImpulseSeeker: "New attempt, fresh energy - make it interesting",
      }
      showToast(`Step 2: ${reframes[userType] || "This is just data for improvement"}`)
    }, 3000)

    // Step 3: Restart with 2-Minute Bridge
    setTimeout(() => {
      showToast("Step 3: Starting 2-Minute Bridge to rebuild momentum")
      startIntegratedBridge(taskName)
    }, 5000)
  }

  // Integrated 2-Minute Bridge
  const startIntegratedBridge = (taskName: string) => {
    const bridgeSession: BridgeSession = {
      id: Date.now().toString(),
      task: taskName,
      duration: 2 * 60,
      completed: false,
      timestamp: new Date().toISOString(),
    }
    setBridgeSessions((prev) => [...prev, bridgeSession])

    setPomodoro({
      timeLeft: 2 * 60,
      isRunning: true,
      mode: "work",
      workSessionsCompleted: 0,
      currentTask: taskName,
      linkedTool: "2-Minute Bridge",
    })
    startPomodoro()

    // Update task with bridge usage
    setTasks((prev) =>
      prev.map((task) =>
        task.name === taskName ? { ...task, bridgeSessionsUsed: (task.bridgeSessionsUsed || 0) + 1 } : task,
      ),
    )
  }

  // Smart Focus Session with Integration
  const startFocusSession = (taskName: string) => {
    // Check if task has assigned core tool
    const task = tasks.find((t) => t.name === taskName)
    const assignedTool = task?.coreToolAssigned

    setFocusSession({
      task: taskName,
      startTime: new Date(),
      distractions: 0,
      isActive: true,
      assignedTool,
      zoneRisk: task?.procrastinationTrigger,
    })

    setPomodoro((prev) => ({
      ...prev,
      currentTask: taskName,
      linkedTool: assignedTool || "",
    }))

    if (assignedTool) {
      showToast(`Focus session started with ${assignedTool} strategy for: ${taskName}`)
    } else {
      showToast(`Focus session started for: ${taskName}`)
    }
  }

  // Integrated Distraction Logging
  const logDistraction = (type: string) => {
    if (focusSession?.isActive) {
      setFocusSession((prev) => ({ ...prev, distractions: prev.distractions + 1 }))
    }

    // Auto-categorize by zone
    const zoneMapping = {
      phone: "Structural Zone",
      "social media": "Structural Zone",
      email: "Structural Zone",
      anxiety: "Emotional Zone",
      boredom: "Mental Zone",
      confusion: "Action Zone",
    }

    const detectedZone =
      Object.entries(zoneMapping).find(([key]) => distractionForm.note.toLowerCase().includes(key))?.[1] || ""

    const newDistraction: Distraction = {
      id: Date.now().toString(),
      ...distractionForm,
      type,
      timestamp: new Date().toISOString(),
      date: currentDate.toISOString().split("T")[0],
      zoneCategory: detectedZone,
    }
    setDistractions((prev) => [...prev, newDistraction])

    // Auto-suggest recovery action based on zone
    if (detectedZone) {
      const recoveryActions = {
        "Structural Zone": "Apply Friction Engineering - remove/block the distraction source",
        "Emotional Zone": "Use Emotion Shield Detector - name the specific feeling",
        "Mental Zone": "Deploy 2-Minute Bridge - start with smallest possible action",
        "Action Zone": "Break task into micro-steps - what's the tiniest first step?",
      }

      const suggestedAction = recoveryActions[detectedZone]
      if (suggestedAction) {
        showToast(`Zone detected: ${detectedZone}. Suggested: ${suggestedAction}`)

        // Auto-update distraction with recovery action
        setDistractions((prev) =>
          prev.map((d) => (d.id === newDistraction.id ? { ...d, recoveryAction: suggestedAction } : d)),
        )
      }
    }

    showToast("Distraction logged with smart zone analysis")
  }

  // Integrated Weekly Insights with Cross-System Analysis
  const generateWeeklyInsights = async () => {
    const procrastinationPatterns = procrastinationLog.reduce((acc: any, event) => {
      acc[event.trigger] = (acc[event.trigger] || 0) + 1
      return acc
    }, {})

    const topTriggers = Object.entries(procrastinationPatterns)
      .sort(([, a]: any, [, b]: any) => b - a)
      .slice(0, 3)
      .map(([trigger]) => trigger)

    const completionRate = (tasks.filter((t) => t.completed).length / (tasks.length || 1)) * 100
    const bridgeSuccessRate = (bridgeSessions.filter((b) => b.completed).length / (bridgeSessions.length || 1)) * 100
    const diagnosticImplementation =
      (diagnosticResults.filter((d) => d.implemented).length / (diagnosticResults.length || 1)) * 100
    const coreToolEffectiveness = coreThreeBlueprint?.effectiveness || 0

    const prompt = `Based on this integrated productivity system data, provide comprehensive insights:
    
    User Type: ${userType}
    Top Procrastination Triggers: ${topTriggers.join(", ")}
    Task Completion Rate: ${Math.round(completionRate)}%
    2-Minute Bridge Success Rate: ${Math.round(bridgeSuccessRate)}%
    Diagnostic Implementation Rate: ${Math.round(diagnosticImplementation)}%
    Core 3 Tool Effectiveness: ${coreToolEffectiveness}%
    Productivity Score: ${productivityScore}%
    Total Distractions: ${distractions.length}
    First Aid Deployments: ${firstAidDeployments.length}
    
    Provide:
    1. Cross-system pattern analysis (how tools are working together)
    2. Specific recommendations for improving tool integration
    3. Predicted high-risk scenarios and prevention strategies
    4. Next week's focus areas for maximum system effectiveness
    5. Personalized tool optimization suggestions
    
    Be specific, actionable, and focus on system synergy.`

    try {
      const insights = await callGeminiAPI(prompt)
      setAiOutput(insights || "Could not generate integrated insights.")
      showToast("Comprehensive system insights generated!")
    } catch (error) {
      showToast("Failed to generate insights", true)
    }
  }

  // Enhanced Pomodoro with Integration
  const startPomodoro = () => {
    if (pomodoro.isRunning) return

    setPomodoro((prev) => ({ ...prev, isRunning: true }))

    pomodoroInterval.current = setInterval(() => {
      setPomodoro((prev) => {
        if (prev.timeLeft <= 1) {
          const newMode = prev.mode === "work" ? "break" : "work"
          const newWorkSessions = prev.mode === "work" ? prev.workSessionsCompleted + 1 : prev.workSessionsCompleted

          if (prev.mode === "work" && focusSession?.isActive) {
            // Complete bridge session if it was a bridge
            if (prev.linkedTool === "2-Minute Bridge") {
              setBridgeSessions((prevSessions) =>
                prevSessions.map((session) =>
                  session.task === prev.currentTask && !session.completed
                    ? {
                        ...session,
                        completed: true,
                        momentum: focusSession.distractions < 2,
                        nextAction: focusSession.distractions < 2 ? "Continue with full session" : "Try again later",
                      }
                    : session,
                ),
              )
            }

            setFocusSession((prevSession) => ({
              ...prevSession,
              isActive: false,
              endTime: new Date(),
              productivity: Math.max(1, 10 - prevSession.distractions),
            }))
          }

          const newTimeLeft = newMode === "work" ? 25 * 60 : newWorkSessions % 4 === 0 ? 15 * 60 : 5 * 60

          const sessionType = prev.linkedTool === "2-Minute Bridge" ? "Bridge" : "Focus"
          showToast(
            prev.mode === "work"
              ? `${sessionType} session complete! ${focusSession?.distractions || 0} distractions logged.`
              : "Break over! Time to get back to work.",
          )

          return {
            ...prev,
            timeLeft: newTimeLeft,
            isRunning: false,
            mode: newMode,
            workSessionsCompleted: newWorkSessions,
            linkedTool: newMode === "work" ? "" : prev.linkedTool,
          }
        }

        return { ...prev, timeLeft: prev.timeLeft - 1 }
      })
    }, 1000)
  }

  const pausePomodoro = () => {
    if (pomodoroInterval.current) {
      clearInterval(pomodoroInterval.current)
    }
    setPomodoro((prev) => ({ ...prev, isRunning: false }))
  }

  const resetPomodoro = () => {
    if (pomodoroInterval.current) {
      clearInterval(pomodoroInterval.current)
    }
    setPomodoro({
      timeLeft: 25 * 60,
      isRunning: false,
      mode: "work",
      workSessionsCompleted: 0,
      currentTask: "",
      linkedTool: "",
    })
    if (focusSession?.isActive) {
      setFocusSession(null)
    }
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const toggleTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((task) => {
        if (task.id === taskId) {
          const wasCompleted = task.completed
          const newCompleted = !wasCompleted

          // If completing a task, update related systems
          if (newCompleted) {
            // Update Core 3 effectiveness if tool was used
            if (task.coreToolAssigned && coreThreeBlueprint) {
              setCoreThreeBlueprint((prev) =>
                prev
                  ? {
                      ...prev,
                      effectiveness: Math.min((prev.effectiveness || 0) + 5, 100),
                      weeklyUsage: {
                        ...prev.weeklyUsage,
                        [task.coreToolAssigned!]: (prev.weeklyUsage?.[task.coreToolAssigned!] || 0) + 1,
                      },
                    }
                  : prev,
              )
            }

            // Update progress rings
            setConsistency((prev) => Math.min(prev + 2, 100))
            setMastery((prev) => Math.min(prev + 1, 100))

            showToast(
              `Task completed! ${task.bridgeSessionsUsed ? `Used ${task.bridgeSessionsUsed} bridge sessions.` : ""}`,
            )
          }

          return {
            ...task,
            completed: newCompleted,
            updatedAt: new Date().toISOString(),
          }
        }
        return task
      }),
    )
  }

  const deleteTask = (taskId: string) => {
    setTasks((prev) => prev.filter((task) => task.id !== taskId))
    showToast("Task deleted!")
  }

  // Integrated Habit Completion
  const completeHabit = (habitId: string) => {
    setHabits((prev) =>
      prev.map((habit) => {
        if (habit.id === habitId) {
          const today = new Date().toISOString().split("T")[0]
          const lastCompleted = habit.lastCompleted
          const isConsecutive =
            lastCompleted && new Date(today).getTime() - new Date(lastCompleted).getTime() === 24 * 60 * 60 * 1000

          const newStreak = isConsecutive || !lastCompleted ? habit.streak + 1 : 1

          // Trigger related system updates based on habit
          if (habit.linkedTool === "5-Zone Diagnostic" && newStreak % 7 === 0) {
            showToast("Weekly diagnostic streak! Your pattern recognition is improving.")
            setMastery((prev) => Math.min(prev + 5, 100))
          }

          if (habit.linkedTool === "2-Minute Bridge" && newStreak >= 3) {
            showToast("Bridge momentum building! Tasks should feel easier to start.")
            setConsistency((prev) => Math.min(prev + 3, 100))
          }

          return {
            ...habit,
            streak: newStreak,
            lastCompleted: today,
          }
        }
        return habit
      }),
    )
    showToast("Habit completed! System integration updated.")
  }

  // Environment optimization with integration
  const checkEnvironment = () => {
    setEnvironmentCheck({
      phone: false,
      notifications: false,
      clutter: false,
      lighting: false,
      noise: false,
      temperature: false,
      checkedAt: new Date().toISOString(),
    })
    setShowEnvironmentModal(true)
  }

  const optimizeEnvironment = () => {
    const issues = Object.entries(environmentCheck)
      .filter(([key, value]) => key !== "checkedAt" && value === true)
      .map(([key]) => key)

    if (issues.length === 0) {
      showToast("Environment optimized! Structural Zone risks minimized.")
      setResilience((prev) => Math.min(prev + 5, 100))
    } else {
      showToast(`Structural Zone issues detected: ${issues.join(", ")}. Apply Friction Engineering!`, true)

      // Auto-log as structural zone distraction
      const environmentDistraction: Distraction = {
        id: Date.now().toString(),
        note: `Environment check revealed: ${issues.join(", ")}`,
        time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        date: currentDate.toISOString().split("T")[0],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        zoneCategory: "Structural Zone",
        recoveryAction: "Apply Friction Engineering to address these issues",
      }
      setDistractions((prev) => [...prev, environmentDistraction])
    }
    setShowEnvironmentModal(false)
  }

  // Schedule management with integration
  const addScheduleBlock = () => {
    const newBlock: ScheduleBlock = {
      id: Date.now().toString(),
      ...blockForm,
      date: currentDate.toISOString().split("T")[0],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    setSchedule((prev) => [...prev, newBlock])
    setShowBlockModal(false)
    resetBlockForm()
    showToast("Schedule block added with smart integration!")
  }

  const updateScheduleBlock = () => {
    if (!editingBlock) return

    setSchedule((prev) =>
      prev.map((block) =>
        block.id === editingBlock.id ? { ...block, ...blockForm, updatedAt: new Date().toISOString() } : block,
      ),
    )
    setShowBlockModal(false)
    setEditingBlock(null)
    resetBlockForm()
    showToast("Schedule block updated!")
  }

  const deleteScheduleBlock = (blockId: string) => {
    setSchedule((prev) => prev.filter((block) => block.id !== blockId))
    showToast("Schedule block deleted!")
  }

  const resetBlockForm = () => {
    setBlockForm({
      activityName: "",
      startTime: "09:00",
      duration: 60,
      progress: 0,
      type: "Flex",
      recurrence: "none",
      youtubeUrl: "",
      subtasks: "",
      zoneDelay: "",
      coreToolUsed: "",
    })
  }

  // Analytics calculations with integration
  const calculateAdherence = () => {
    const totalMinutes = schedule.reduce((sum, block) => sum + block.duration, 0)
    const completedMinutes = schedule.reduce((sum, block) => sum + (block.progress === 100 ? block.duration : 0), 0)
    return totalMinutes > 0 ? Math.round((completedMinutes / totalMinutes) * 100) : 0
  }

  const calculateFocusEfficiency = () => {
    const deepWorkBlocks = schedule.filter((block) => block.type === "Flex")
    const totalDeepWork = deepWorkBlocks.reduce((sum, block) => sum + block.duration, 0)
    const completedDeepWork = deepWorkBlocks.reduce(
      (sum, block) => sum + (block.progress === 100 ? block.duration : 0),
      0,
    )
    return totalDeepWork > 0 ? Math.round((completedDeepWork / totalDeepWork) * 100) : 0
  }

  const toggleFriction = (key: string) => {
    setFrictionEngineering((prev) => ({ ...prev, [key]: !prev[key] }))
    showToast(`Friction for ${key} ${frictionEngineering[key] ? "enabled" : "disabled"}`)
  }

  // AI Integration
  const generateAISubtasks = async () => {
    if (!blockForm.activityName.trim()) {
      showToast("Please enter an activity name first", true)
      return
    }

    try {
      const response = await fetch("/api/gemini", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: `Break down the activity "${blockForm.activityName}" into a list of actionable subtasks. Consider the user's procrastination type: ${userType}. Provide only the list of subtasks, one per line, without any introductory or concluding remarks.`,
        }),
      })

      const { result } = await response.json()
      setBlockForm((prev) => ({ ...prev, subtasks: result || "Could not generate subtasks." }))
      showToast("Subtasks generated with personalization!")
    } catch (error) {
      showToast("Failed to generate subtasks", true)
    }
  }

  // Progress Ring Component
  const ProgressRing = ({ value, label, color = "#84A98C" }: { value: number; label: string; color?: string }) => {
    const circumference = 2 * Math.PI * 40
    const offset = circumference - (value / 100) * circumference

    return (
      <div className="text-center">
        <div className="mx-auto w-20 h-20 relative">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" stroke="#E5E7EB" strokeWidth="8" fill="none" />
            <circle
              cx="50"
              cy="50"
              r="40"
              stroke={color}
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              className="transition-all duration-1000"
            />
          </svg>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <span className="text-lg font-bold" style={{ color }}>
              {value}%
            </span>
          </div>
        </div>
        <p className="mt-2 font-medium text-sm text-gray-600">{label}</p>
      </div>
    )
  }

  const adherence = calculateAdherence()
  const focusEfficiency = calculateFocusEfficiency()

  return (
    <div className="bg-[#F8F7F2] text-gray-700 min-h-screen">
      {/* Header */}
      <header className="bg-white shadow-sm p-4 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-[#354F52] flex items-center">
              <i className="fas fa-brain text-[#84A98C] mr-2"></i>
              Integrated ProductivityOS
              <span className="ml-2 text-lg font-bold text-[#84A98C]">{productivityScore}%</span>
            </h1>
            <p className="text-gray-500 text-sm">
              {currentDate.toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setShowProcrastinationModal(true)}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              <i className="fas fa-exclamation-triangle mr-2"></i>Log Event
            </button>
            <button
              onClick={checkEnvironment}
              className="bg-[#354F52] hover:bg-[#52796F] text-white px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              <i className="fas fa-cog mr-2"></i>Zone Check
            </button>
            <button
              onClick={generateWeeklyInsights}
              className="bg-[#84A98C] hover:bg-[#52796F] text-white px-4 py-2 rounded-lg font-semibold transition-colors"
            >
              <i className="fas fa-brain mr-2"></i>System Insights
            </button>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Tab Navigation */}
          <nav className="flex border-b border-gray-200 mb-6 bg-white rounded-lg shadow-sm">
            {[
              { id: "dashboard", icon: "tachometer-alt", label: "Dashboard" },
              { id: "schedule", icon: "calendar-alt", label: "Schedule" },
              { id: "habits", icon: "check-circle", label: "Habits" },
              { id: "analysis", icon: "chart-bar", label: "Analysis" },
              { id: "advanced-system", icon: "brain", label: "Advanced Tools" },
              { id: "analytics", icon: "chart-line", label: "Analytics" },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-3 px-2 text-center text-xs font-semibold border-b-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-[#84A98C] text-[#354F52] bg-green-50"
                    : "border-transparent text-gray-500 hover:text-[#354F52] hover:bg-gray-50"
                }`}
              >
                <i className={`fas fa-${tab.icon} mr-1`}></i>
                {tab.label}
              </button>
            ))}
          </nav>

          {/* Dashboard Tab - New Integrated Overview */}
          {activeTab === "dashboard" && (
            <div className="space-y-6">
              {/* System Status Overview */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                  <h3 className="text-lg font-bold text-[#354F52] mb-4 flex items-center">
                    <i className="fas fa-brain text-[#84A98C] mr-2"></i>
                    Neural Development
                  </h3>
                  <div className="grid grid-cols-3 gap-4">
                    <ProgressRing value={consistency} label="Consistency" color="#10B981" />
                    <ProgressRing value={mastery} label="Mastery" color="#3B82F6" />
                    <ProgressRing value={resilience} label="Resilience" color="#8B5CF6" />
                  </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                  <h3 className="text-lg font-bold text-[#354F52] mb-4 flex items-center">
                    <i className="fas fa-chart-line text-[#84A98C] mr-2"></i>
                    System Performance
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Task Completion</span>
                      <span className="font-bold">
                        {Math.round((tasks.filter((t) => t.completed).length / (tasks.length || 1)) * 100)}%
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Bridge Success</span>
                      <span className="font-bold">
                        {Math.round(
                          (bridgeSessions.filter((b) => b.completed).length / (bridgeSessions.length || 1)) * 100,
                        )}
                        %
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Diagnostic Implementation</span>
                      <span className="font-bold">
                        {Math.round(
                          (diagnosticResults.filter((d) => d.implemented).length / (diagnosticResults.length || 1)) *
                            100,
                        )}
                        %
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Core 3 Effectiveness</span>
                      <span className="font-bold">{coreThreeBlueprint?.effectiveness || 0}%</span>
                    </div>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
                  <h3 className="text-lg font-bold text-[#354F52] mb-4 flex items-center">
                    <i className="fas fa-shield-alt text-[#84A98C] mr-2"></i>
                    Risk Assessment
                  </h3>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm">Recent Procrastination Events</span>
                      <span className="font-bold text-red-600">
                        {
                          procrastinationLog.filter(
                            (e) => new Date(e.timestamp).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000,
                          ).length
                        }
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">First Aid Deployments</span>
                      <span className="font-bold text-orange-600">{firstAidDeployments.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Structural Zone Issues</span>
                      <span className="font-bold text-yellow-600">
                        {distractions.filter((d) => d.zoneCategory === "Structural Zone").length}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Recent Activity Feed */}
              <div className="bg-white rounded-lg p-6 shadow-md border border-gray-200">
                <h3 className="text-xl font-bold text-[#354F52] mb-4 flex items-center">
                  <i className="fas fa-stream text-[#84A98C] mr-2"></i>
                  Recent System Activity
                </h3>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {/* Combine all recent activities */}
                  {[
                    ...bridgeSessions.slice(-3).map((session) => ({
                      type: "bridge",
                      time: session.timestamp,
                      message: `2-Minute Bridge ${session.completed ? "completed" : "started"} for: ${session.task}`,
                      icon: "bridge",
                      color: session.completed ? "text-green-600" : "text-blue-600",
                    })),
                    ...procrastinationLog.slice(-2).map((event) => ({
                      type: "procrastination",
                      time: event.timestamp,
                      message: `Procrastination logged: ${event.task} (${event.trigger})`,
                      icon: "exclamation-triangle",
                      color: "text-red-600",
                    })),
                    ...firstAidDeployments.slice(-2).map((deployment) => ({
                      type: "firstaid",
                      time: deployment.timestamp,
                      message: `First Aid deployed: ${deployment.tool}`,
                      icon: "first-aid",
                      color: "text-orange-600",
                    })),
                  ]
                    .sort((a, b) => new Date(b.time).getTime() - new Date(a.time).getTime())
                    .slice(0, 8)
                    .map((activity, index) => (
                      <div key={index} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
                        <i className={`fas fa-${activity.icon} ${activity.color}`}></i>
                        <div className="flex-1">
                          <p className="text-sm text-gray-700">{activity.message}</p>
                          <p className="text-xs text-gray-500">{new Date(activity.time).toLocaleString()}</p>
                        </div>
                      </div>
                    ))}
                </div>
              </div>

              {/* Quick Actions */}
              <div className="bg-white rounded-lg p-6 shadow-md border border-gray-200">
                <h3 className="text-xl font-bold text-[#354F52] mb-4 flex items-center">
                  <i className="fas fa-bolt text-[#84A98C] mr-2"></i>
                  Smart Quick Actions
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <button
                    onClick={() => setActiveTab("advanced-system")}
                    className="p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors"
                  >
                    <i className="fas fa-search text-blue-600 text-2xl mb-2"></i>
                    <div className="text-sm font-semibold text-blue-800">Run 5-Zone Diagnostic</div>
                  </button>

                  <button
                    onClick={() => startIntegratedBridge("Current stuck task")}
                    className="p-4 bg-green-50 hover:bg-green-100 rounded-lg border border-green-200 transition-colors"
                  >
                    <i className="fas fa-bridge text-green-600 text-2xl mb-2"></i>
                    <div className="text-sm font-semibold text-green-800">Start 2-Min Bridge</div>
                  </button>

                  <button
                    onClick={checkEnvironment}
                    className="p-4 bg-orange-50 hover:bg-orange-100 rounded-lg border border-orange-200 transition-colors"
                  >
                    <i className="fas fa-cog text-orange-600 text-2xl mb-2"></i>
                    <div className="text-sm font-semibold text-orange-800">Environment Check</div>
                  </button>

                  <button
                    onClick={generateWeeklyInsights}
                    className="p-4 bg-purple-50 hover:bg-purple-100 rounded-lg border border-purple-200 transition-colors"
                  >
                    <i className="fas fa-brain text-purple-600 text-2xl mb-2"></i>
                    <div className="text-sm font-semibold text-purple-800">Generate Insights</div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Schedule Tab */}
          {activeTab === "schedule" && (
            <div>
              {/* Energy Forecast */}
              <section className="mb-6">
                <h3 className="text-lg font-semibold text-[#354F52] mb-3">Energy Forecast</h3>
                <div className="flex items-end h-24 bg-white rounded-lg p-4 gap-1 shadow-md border border-gray-200">
                  {ENERGY_LEVELS.map((energy, index) => (
                    <div
                      key={index}
                      className={`flex-1 ${energy.color} ${energy.height} rounded-md flex items-center justify-center text-xs font-semibold text-white`}
                      title={energy.level}
                    />
                  ))}
                </div>
              </section>

              {/* Schedule Canvas */}
              <section className="mb-6">
                <h3 className="text-lg font-semibold text-[#354F52] mb-3">Today's Integrated Schedule</h3>
                <div className="bg-white rounded-lg p-4 min-h-96 shadow-md border border-gray-200">
                  {schedule.length === 0 ? (
                    <div className="text-center text-gray-500 py-12">
                      <i className="fas fa-calendar-plus text-4xl mb-4 text-[#84A98C]"></i>
                      <p>No schedule blocks yet. Click "Add Block" to get started!</p>
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {schedule.map((block) => (
                        <div
                          key={block.id}
                          className={`${BLOCK_TYPES[block.type as keyof typeof BLOCK_TYPES]?.color || "bg-gray-400"} rounded-lg p-3 text-white cursor-pointer hover:opacity-80 transition-opacity shadow-sm`}
                          onClick={() => {
                            setEditingBlock(block)
                            setBlockForm({
                              activityName: block.activityName,
                              startTime: block.startTime,
                              duration: block.duration,
                              progress: block.progress,
                              type: block.type,
                              recurrence: block.recurrence,
                              youtubeUrl: block.youtubeUrl || "",
                              subtasks: block.subtasks || "",
                              zoneDelay: block.zoneDelay || "",
                              coreToolUsed: block.coreToolUsed || "",
                            })
                            setShowBlockModal(true)
                          }}
                        >
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-semibold">{block.activityName}</span>
                            <div className="flex gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation()
                                  startFocusSession(block.activityName)
                                }}
                                className="bg-white/20 hover:bg-white/30 px-2 py-1 rounded text-xs"
                              >
                                <i className="fas fa-play mr-1"></i>Focus
                              </button>
                              <span className="text-sm opacity-90">
                                {block.startTime} ({block.duration}min)
                              </span>
                            </div>
                          </div>
                          {(block.zoneDelay || block.coreToolUsed) && (
                            <div className="text-xs opacity-75 mb-1">
                              {block.zoneDelay && <span>Zone: {block.zoneDelay} | </span>}
                              {block.coreToolUsed && <span>Tool: {block.coreToolUsed}</span>}
                            </div>
                          )}
                          <div className="w-full bg-white/30 rounded-full h-2">
                            <div
                              className="h-full bg-white rounded-full transition-all"
                              style={{ width: `${block.progress}%` }}
                            />
                          </div>
                          <div className="text-right text-sm opacity-90 mt-1">{block.progress}% complete</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </section>

              {/* Activity Palette */}
              <section>
                <h3 className="text-lg font-semibold text-[#354F52] mb-3">Quick Add</h3>
                <div className="flex flex-wrap gap-2">
                  {Object.entries(BLOCK_TYPES).map(([key, value]) => (
                    <button
                      key={key}
                      onClick={() => {
                        setBlockForm((prev) => ({ ...prev, type: key }))
                        setShowBlockModal(true)
                      }}
                      className={`px-4 py-2 rounded-lg font-semibold text-white transition-colors ${value.color} hover:opacity-80 shadow-sm`}
                    >
                      {value.name}
                    </button>
                  ))}
                </div>
              </section>
            </div>
          )}

          {/* Habits Tab */}
          {activeTab === "habits" && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg p-6 shadow-md border border-gray-200">
                <h3 className="text-2xl font-bold text-[#354F52] mb-4 flex items-center">
                  <i className="fas fa-check-circle text-[#84A98C] mr-3"></i>
                  Integrated Habit System
                </h3>
                <p className="text-gray-600 mb-6">
                  Habits linked to your anti-procrastination tools for maximum effectiveness
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {habits.map((habit) => (
                    <div key={habit.id} className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h5 className="font-bold text-[#354F52]">{habit.name}</h5>
                          <p className="text-sm text-gray-600">{habit.category}</p>
                          {habit.linkedTool && (
                            <p className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded mt-1">
                              Linked: {habit.linkedTool}
                            </p>
                          )}
                          <div className="flex items-center mt-2">
                            <span className="text-2xl font-bold text-[#84A98C] mr-2">{habit.streak}</span>
                            <span className="text-sm text-gray-500">day streak</span>
                          </div>
                        </div>
                        <button
                          onClick={() => completeHabit(habit.id)}
                          className="bg-[#84A98C] hover:bg-[#52796F] text-white px-3 py-1 rounded text-sm transition-colors"
                        >
                          <i className="fas fa-check mr-1"></i>
                          Complete
                        </button>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="h-full bg-[#84A98C] rounded-full transition-all"
                          style={{ width: `${Math.min((habit.streak / 30) * 100, 100)}%` }}
                        />
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Target: {habit.target} times {habit.frequency}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Analysis Tab */}
          {activeTab === "analysis" && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg p-6 shadow-md border border-gray-200">
                <h3 className="text-2xl font-bold text-[#354F52] mb-4 flex items-center">
                  <i className="fas fa-chart-bar text-[#84A98C] mr-3"></i>
                  Integrated System Analysis
                </h3>
                <p className="text-gray-600 mb-6">Cross-system pattern analysis showing how all tools work together</p>

                {/* System Integration Metrics */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                    <h4 className="font-bold text-blue-800 mb-2">Tool Synergy Score</h4>
                    <div className="text-3xl font-bold text-blue-600 mb-1">
                      {Math.round(
                        (bridgeSessions.filter((b) => b.completed).length / (bridgeSessions.length || 1)) * 30 +
                          (diagnosticResults.filter((d) => d.implemented).length / (diagnosticResults.length || 1)) *
                            40 +
                          ((coreThreeBlueprint?.effectiveness || 0) / 100) * 30,
                      )}
                      %
                    </div>
                    <p className="text-sm text-blue-700">How well tools work together</p>
                  </div>

                  <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                    <h4 className="font-bold text-green-800 mb-2">Prevention Success</h4>
                    <div className="text-3xl font-bold text-green-600 mb-1">
                      {Math.round(
                        ((7 -
                          procrastinationLog.filter(
                            (e) => new Date(e.timestamp).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000,
                          ).length) /
                          7) *
                          100,
                      )}
                      %
                    </div>
                    <p className="text-sm text-green-700">Procrastination events prevented</p>
                  </div>

                  <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                    <h4 className="font-bold text-purple-800 mb-2">Recovery Speed</h4>
                    <div className="text-3xl font-bold text-purple-600 mb-1">
                      {firstAidDeployments.length > 0
                        ? Math.round((firstAidDeployments.length / procrastinationLog.length) * 100)
                        : 0}
                      %
                    </div>
                    <p className="text-sm text-purple-700">Quick recovery rate</p>
                  </div>
                </div>

                {/* Cross-System Patterns */}
                <div className="mb-6">
                  <h4 className="text-lg font-semibold text-[#354F52] mb-3">Cross-System Pattern Detection</h4>
                  <div className="space-y-3">
                    {/* Bridge to Task Completion Pattern */}
                    <div className="bg-gray-50 p-4 rounded border">
                      <h5 className="font-semibold text-gray-800 mb-2">Bridge → Task Completion Pattern</h5>
                      <div className="flex items-center gap-4">
                        <div className="text-sm text-gray-600">
                          Tasks using bridges: {tasks.filter((t) => (t.bridgeSessionsUsed || 0) > 0).length}
                        </div>
                        <div className="text-sm text-gray-600">
                          Completion rate:{" "}
                          {Math.round(
                            (tasks.filter((t) => t.completed && (t.bridgeSessionsUsed || 0) > 0).length /
                              (tasks.filter((t) => (t.bridgeSessionsUsed || 0) > 0).length || 1)) *
                              100,
                          )}
                          %
                        </div>
                      </div>
                    </div>

                    {/* Zone to Tool Effectiveness */}
                    <div className="bg-gray-50 p-4 rounded border">
                      <h5 className="font-semibold text-gray-800 mb-2">Zone Detection → Tool Deployment</h5>
                      <div className="text-sm text-gray-600">
                        Distractions with zone identification: {distractions.filter((d) => d.zoneCategory).length} /{" "}
                        {distractions.length}
                      </div>
                      <div className="text-sm text-gray-600">
                        Recovery actions suggested: {distractions.filter((d) => d.recoveryAction).length}
                      </div>
                    </div>

                    {/* Habit to System Performance */}
                    <div className="bg-gray-50 p-4 rounded border">
                      <h5 className="font-semibold text-gray-800 mb-2">Habit Consistency → System Performance</h5>
                      <div className="text-sm text-gray-600">
                        Average habit streak:{" "}
                        {Math.round(habits.reduce((sum, h) => sum + h.streak, 0) / (habits.length || 1))} days
                      </div>
                      <div className="text-sm text-gray-600">
                        Productivity correlation:{" "}
                        {Math.round((habits.reduce((sum, h) => sum + h.streak, 0) / (habits.length || 1) / 30) * 100)}%
                      </div>
                    </div>
                  </div>
                </div>

                {/* AI System Insights */}
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="text-lg font-semibold text-[#354F52] mb-2">AI System Integration Analysis</h4>
                  <div className="text-sm text-gray-700 whitespace-pre-wrap">
                    {aiOutput ||
                      "Generate system insights to see how all your tools are working together and get personalized optimization recommendations."}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Advanced System Tab */}
          {activeTab === "advanced-system" && (
            <div className="space-y-8">
              <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-[#354F52] mb-4 flex items-center justify-center">
                  <i className="fas fa-brain text-[#84A98C] mr-3"></i>
                  Integrated Advanced System
                </h3>
                <p className="text-gray-600 max-w-3xl mx-auto">
                  All tools work together seamlessly - diagnostics inform interventions, bridges build momentum, and
                  your system adapts based on real usage patterns.
                </p>
              </div>

              <FiveZoneDiagnostic />
              <FirstAidKit />
              <TwoMinuteBridge />
              <CoreThreeSelector />
              <EnhancedSevenDayProgram />
            </div>
          )}

          {/* Analytics Tab */}
          {activeTab === "analytics" && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-lg text-center shadow-md border border-gray-200">
                  <h4 className="text-sm font-semibold text-gray-500 mb-2">Schedule Adherence</h4>
                  <div className="text-4xl font-bold text-[#84A98C] mb-2">{adherence}%</div>
                  <p className="text-xs text-gray-500">
                    {adherence >= 80 ? "Excellent!" : adherence >= 50 ? "Good Progress" : "Needs Work"}
                  </p>
                </div>
                <div className="bg-white p-6 rounded-lg text-center shadow-md border border-gray-200">
                  <h4 className="text-sm font-semibold text-gray-500 mb-2">Focus Efficiency</h4>
                  <div className="text-4xl font-bold text-[#52796F] mb-2">{focusEfficiency}%</div>
                  <p className="text-xs text-gray-500">Deep work completion</p>
                </div>
              </div>

              <div className="bg-white rounded-lg p-6 shadow-md border border-gray-200">
                <h4 className="text-base font-semibold text-[#354F52] mb-4">Integrated System Performance</h4>
                <div className="grid grid-cols-3 gap-6">
                  <ProgressRing value={consistency} label="Consistency" color="#10B981" />
                  <ProgressRing value={mastery} label="Mastery" color="#3B82F6" />
                  <ProgressRing value={resilience} label="Resilience" color="#8B5CF6" />
                </div>
              </div>

              <div className="bg-white rounded-lg p-6 shadow-md border border-gray-200">
                <h4 className="text-base font-semibold text-[#354F52] mb-4">System Integration Metrics</h4>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Bridge Sessions Completed</span>
                    <span className="font-bold text-[#84A98C]">
                      {bridgeSessions.filter((b) => b.completed).length} / {bridgeSessions.length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Diagnostic Implementations</span>
                    <span className="font-bold text-[#84A98C]">
                      {diagnosticResults.filter((d) => d.implemented).length} / {diagnosticResults.length}
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">First Aid Deployments</span>
                    <span className="font-bold text-[#84A98C]">{firstAidDeployments.length}</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Core 3 Effectiveness</span>
                    <span className="font-bold text-[#84A98C]">{coreThreeBlueprint?.effectiveness || 0}%</span>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Enhanced Sidebar with Integration */}
        <aside className="w-80 bg-white border-l border-gray-200 p-4 shadow-sm">
          {/* Integrated Productivity Score */}
          <div className="bg-gradient-to-r from-green-50 to-blue-50 p-4 rounded-lg text-center mb-6 border border-gray-200">
            <h4 className="text-sm font-semibold text-gray-600 mb-2">Integrated System Score</h4>
            <div className="text-4xl font-bold text-[#84A98C] mb-2">{productivityScore}%</div>
            <p className="text-xs text-gray-500">
              {productivityScore >= 80
                ? "System Mastery!"
                : productivityScore >= 60
                  ? "Good Integration!"
                  : "Building Momentum!"}
            </p>
            <div className="mt-2 text-xs text-gray-600">
              <div>Tasks: {Math.round((tasks.filter((t) => t.completed).length / (tasks.length || 1)) * 100)}%</div>
              <div>
                Bridges:{" "}
                {Math.round((bridgeSessions.filter((b) => b.completed).length / (bridgeSessions.length || 1)) * 100)}%
              </div>
              <div>Tools: {coreThreeBlueprint?.effectiveness || 0}%</div>
            </div>
          </div>

          {/* Enhanced Pomodoro with Integration */}
          <div className="bg-gray-50 p-4 rounded-lg text-center mb-6 border border-gray-200">
            <p className="text-sm text-gray-600 mb-2">
              {pomodoro.currentTask
                ? `${pomodoro.linkedTool ? `[${pomodoro.linkedTool}] ` : ""}${pomodoro.currentTask}`
                : `Current Session: ${pomodoro.mode === "work" ? "Work" : "Break"}`}
            </p>
            <div className="text-4xl font-mono font-bold my-4 text-[#354F52]">{formatTime(pomodoro.timeLeft)}</div>
            <div className="flex justify-center gap-3 mb-3">
              <button
                onClick={startPomodoro}
                disabled={pomodoro.isRunning}
                className="w-12 h-12 bg-[#84A98C] hover:bg-[#52796F] disabled:opacity-50 rounded-full flex items-center justify-center text-xl text-white"
              >
                <i className="fas fa-play"></i>
              </button>
              <button
                onClick={pausePomodoro}
                disabled={!pomodoro.isRunning}
                className="w-12 h-12 bg-yellow-500 hover:bg-yellow-600 disabled:opacity-50 rounded-full flex items-center justify-center text-xl text-white"
              >
                <i className="fas fa-pause"></i>
              </button>
              <button
                onClick={resetPomodoro}
                className="w-12 h-12 bg-red-500 hover:bg-red-600 rounded-full flex items-center justify-center text-xl text-white"
              >
                <i className="fas fa-sync-alt"></i>
              </button>
            </div>
            {focusSession?.isActive && (
              <div className="text-xs text-gray-600">
                <p>Distractions: {focusSession.distractions}</p>
                {focusSession.assignedTool && <p className="text-blue-600">Using: {focusSession.assignedTool}</p>}
                <button
                  onClick={() => logDistraction("manual")}
                  className="mt-1 text-red-500 hover:text-red-700 text-xs"
                >
                  <i className="fas fa-exclamation-triangle mr-1"></i>
                  Log Distraction
                </button>
              </div>
            )}
            <p className="text-xs text-gray-500 mt-2">Sessions: {pomodoro.workSessionsCompleted}</p>
          </div>

          {/* Smart Task List with Integration */}
          <div className="bg-gray-50 p-4 rounded-lg mb-6 border border-gray-200">
            <div className="flex justify-between items-center mb-3">
              <h4 className="text-base font-semibold text-[#354F52]">Smart Tasks ({tasks.length})</h4>
            </div>
            <div className="flex mb-2">
              <input
                type="text"
                value={newTaskName}
                onChange={(e) => setNewTaskName(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && addTask()}
                className="flex-grow bg-white border border-gray-300 rounded-l-md px-3 py-2 text-gray-700 text-sm focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                placeholder="Add task (auto-detects triggers)..."
              />
              <button
                onClick={addTask}
                className="bg-[#84A98C] hover:bg-[#52796F] text-white px-4 py-2 rounded-r-md text-sm font-semibold"
              >
                Add
              </button>
            </div>
            <select
              value={newTaskPriority}
              onChange={(e) => setNewTaskPriority(e.target.value as any)}
              className="w-full bg-white border border-gray-300 rounded-md px-3 py-1 text-gray-700 text-sm mb-3"
            >
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
              <option value="urgent">Urgent</option>
            </select>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {tasks.length === 0 ? (
                <p className="text-gray-500 text-sm">No tasks added yet.</p>
              ) : (
                tasks
                  .sort((a, b) => {
                    const priorityOrder = { urgent: 4, high: 3, medium: 2, low: 1 }
                    return priorityOrder[b.priority] - priorityOrder[a.priority]
                  })
                  .map((task) => (
                    <div
                      key={task.id}
                      className={`flex items-center gap-2 p-2 bg-white rounded text-sm border border-gray-200 ${
                        task.completed ? "opacity-60 line-through" : ""
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={task.completed}
                        onChange={() => toggleTask(task.id)}
                        className="form-checkbox h-4 w-4 text-[#84A98C] rounded"
                      />
                      <div className="flex-grow">
                        <span className="text-gray-700">{task.name}</span>
                        <div className="flex gap-1 mt-1">
                          <span
                            className={`text-xs px-1 py-0.5 rounded ${
                              task.priority === "urgent"
                                ? "bg-red-100 text-red-700"
                                : task.priority === "high"
                                  ? "bg-orange-100 text-orange-700"
                                  : task.priority === "medium"
                                    ? "bg-yellow-100 text-yellow-700"
                                    : "bg-gray-100 text-gray-700"
                            }`}
                          >
                            {task.priority}
                          </span>
                          {task.procrastinationTrigger && (
                            <span className="text-xs px-1 py-0.5 rounded bg-red-100 text-red-700">
                              {task.procrastinationTrigger}
                            </span>
                          )}
                          {task.coreToolAssigned && (
                            <span className="text-xs px-1 py-0.5 rounded bg-blue-100 text-blue-700">
                              {task.coreToolAssigned}
                            </span>
                          )}
                          {(task.bridgeSessionsUsed || 0) > 0 && (
                            <span className="text-xs px-1 py-0.5 rounded bg-green-100 text-green-700">
                              {task.bridgeSessionsUsed} bridges
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => startFocusSession(task.name)}
                        className="text-[#84A98C] hover:text-[#52796F] text-xs"
                      >
                        <i className="fas fa-play"></i>
                      </button>
                      <button
                        onClick={() => deleteTask(task.id)}
                        className="text-gray-400 hover:text-red-500 transition-colors"
                      >
                        <i className="fas fa-trash-alt"></i>
                      </button>
                    </div>
                  ))
              )}
            </div>
          </div>

          {/* System Integration Status */}
          <div className="bg-gray-50 p-4 rounded-lg mb-6 border border-gray-200">
            <h4 className="text-base font-semibold text-[#354F52] mb-3">System Integration</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Bridge Sessions</span>
                <span className="font-bold text-green-600">{bridgeSessions.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Zone Diagnostics</span>
                <span className="font-bold text-blue-600">{diagnosticResults.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">First Aid Deployed</span>
                <span className="font-bold text-orange-600">{firstAidDeployments.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Core 3 Active</span>
                <span className="font-bold text-purple-600">{coreThreeBlueprint ? "Yes" : "No"}</span>
              </div>
            </div>
          </div>

          {/* AI Insights with Integration */}
          <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
            <h4 className="text-base font-semibold text-[#354F52] mb-3">Integrated AI Insights</h4>
            <div className="p-3 bg-white rounded-md min-h-[100px] text-gray-700 text-sm whitespace-pre-wrap border border-gray-300">
              {aiOutput ||
                "Generate system insights to see how all your tools work together and get optimization recommendations."}
            </div>
            <button
              onClick={generateWeeklyInsights}
              className="w-full mt-3 bg-[#84A98C] hover:bg-[#52796F] text-white px-3 py-2 rounded-md text-sm font-semibold"
            >
              <i className="fas fa-brain mr-2"></i>Generate System Insights
            </button>
          </div>
        </aside>
      </div>

      {/* All existing modals remain the same but with enhanced integration */}
      {/* Procrastination Log Modal with Integration */}
      {showProcrastinationModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl p-6 w-full max-w-md border border-gray-300">
            <h2 className="text-2xl font-bold mb-4 text-[#354F52]">Log Procrastination Event</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Task You Avoided</label>
                <input
                  type="text"
                  value={procrastinationForm.task}
                  onChange={(e) => setProcrastinationForm((prev) => ({ ...prev, task: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  placeholder="What task did you procrastinate on?"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Primary Trigger</label>
                <select
                  value={procrastinationForm.trigger}
                  onChange={(e) => setProcrastinationForm((prev) => ({ ...prev, trigger: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  required
                >
                  <option value="">Select a trigger...</option>
                  {PROCRASTINATION_TRIGGERS.map((trigger) => (
                    <option key={trigger} value={trigger}>
                      {trigger}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Zone Identified</label>
                <select
                  value={procrastinationForm.zoneIdentified}
                  onChange={(e) => setProcrastinationForm((prev) => ({ ...prev, zoneIdentified: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                >
                  <option value="">Select zone (optional)...</option>
                  {FIVE_ZONE_DELAYS.map((zone) => (
                    <option key={zone.zone} value={zone.zone}>
                      {zone.zone}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Emotion Felt</label>
                <input
                  type="text"
                  value={procrastinationForm.emotion}
                  onChange={(e) => setProcrastinationForm((prev) => ({ ...prev, emotion: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  placeholder="Anxious, overwhelmed, bored, etc."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Strategy Used</label>
                <input
                  type="text"
                  value={procrastinationForm.strategy}
                  onChange={(e) => setProcrastinationForm((prev) => ({ ...prev, strategy: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  placeholder="What did you try to overcome it?"
                />
              </div>
              <div>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={procrastinationForm.bridgeUsed}
                    onChange={(e) => setProcrastinationForm((prev) => ({ ...prev, bridgeUsed: e.target.checked }))}
                    className="form-checkbox h-4 w-4 text-[#84A98C] rounded"
                  />
                  <span className="text-sm text-gray-600">Used 2-Minute Bridge</span>
                </label>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">
                  Strategy Effectiveness: {procrastinationForm.effectiveness}/10
                </label>
                <input
                  type="range"
                  value={procrastinationForm.effectiveness}
                  onChange={(e) =>
                    setProcrastinationForm((prev) => ({ ...prev, effectiveness: Number.parseInt(e.target.value) }))
                  }
                  className="w-full accent-[#84A98C]"
                  min="1"
                  max="10"
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setShowProcrastinationModal(false)}
                className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600"
              >
                Cancel
              </button>
              <button
                onClick={logProcrastinationEvent}
                className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
              >
                Log & Execute Reset Ritual
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Environment Check Modal */}
      {showEnvironmentModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl p-6 w-full max-w-md border border-gray-300">
            <h2 className="text-2xl font-bold mb-4 text-[#354F52]">Structural Zone Check</h2>
            <p className="text-gray-600 mb-4">Check any issues present in your current environment:</p>
            <div className="space-y-3">
              {[
                { key: "phone", label: "Phone visible/accessible", icon: "mobile-alt" },
                { key: "notifications", label: "Notifications enabled", icon: "bell" },
                { key: "clutter", label: "Cluttered workspace", icon: "boxes" },
                { key: "lighting", label: "Poor lighting", icon: "lightbulb" },
                { key: "noise", label: "Distracting noise", icon: "volume-up" },
                { key: "temperature", label: "Uncomfortable temperature", icon: "thermometer-half" },
              ].map((item) => (
                <label key={item.key} className="flex items-center gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={environmentCheck[item.key] || false}
                    onChange={(e) => setEnvironmentCheck((prev) => ({ ...prev, [item.key]: e.target.checked }))}
                    className="form-checkbox h-4 w-4 text-red-500 rounded"
                  />
                  <i className={`fas fa-${item.icon} text-gray-500 w-4`}></i>
                  <span className="text-gray-700">{item.label}</span>
                </label>
              ))}
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setShowEnvironmentModal(false)}
                className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600"
              >
                Cancel
              </button>
              <button
                onClick={optimizeEnvironment}
                className="px-4 py-2 bg-[#84A98C] text-white rounded-md hover:bg-[#52796F]"
              >
                Optimize & Log Issues
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Enhanced Distraction Modal */}
      {showDistractionModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl p-6 w-full max-w-md border border-gray-300">
            <h2 className="text-2xl font-bold mb-4 text-[#354F52]">Log Smart Distraction</h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Distraction Description</label>
                <input
                  type="text"
                  value={distractionForm.note}
                  onChange={(e) => setDistractionForm((prev) => ({ ...prev, note: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  placeholder="What distracted you? (auto-detects zone)"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Time</label>
                <input
                  type="time"
                  value={distractionForm.time}
                  onChange={(e) => setDistractionForm((prev) => ({ ...prev, time: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Trigger/Source</label>
                <input
                  type="text"
                  value={distractionForm.trigger}
                  onChange={(e) => setDistractionForm((prev) => ({ ...prev, trigger: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  placeholder="Phone, email, noise, etc."
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">
                  Intensity: {distractionForm.intensity}/10
                </label>
                <input
                  type="range"
                  value={distractionForm.intensity}
                  onChange={(e) =>
                    setDistractionForm((prev) => ({ ...prev, intensity: Number.parseInt(e.target.value) }))
                  }
                  className="w-full accent-[#84A98C]"
                  min="1"
                  max="10"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">
                  Duration: {distractionForm.duration} minutes
                </label>
                <input
                  type="range"
                  value={distractionForm.duration}
                  onChange={(e) =>
                    setDistractionForm((prev) => ({ ...prev, duration: Number.parseInt(e.target.value) }))
                  }
                  className="w-full accent-[#84A98C]"
                  min="1"
                  max="60"
                />
              </div>
            </div>
            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => setShowDistractionModal(false)}
                className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const newDistraction: Distraction = {
                    id: Date.now().toString(),
                    ...distractionForm,
                    date: currentDate.toISOString().split("T")[0],
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString(),
                  }
                  setDistractions((prev) => [...prev, newDistraction])
                  logDistraction("manual")
                  setShowDistractionModal(false)
                  setDistractionForm({
                    note: "",
                    time: "",
                    trigger: "",
                    intensity: 5,
                    duration: 5,
                    zoneCategory: "",
                    recoveryAction: "",
                  })
                }}
                className="px-4 py-2 bg-[#84A98C] text-white rounded-md hover:bg-[#52796F]"
              >
                Log with Smart Analysis
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Block Editor Modal with Integration */}
      {showBlockModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-2xl p-6 w-full max-w-2xl border border-gray-300">
            <h2 className="text-2xl font-bold mb-4 text-[#354F52]">
              {editingBlock ? "Edit Integrated Block" : "Add Smart Schedule Block"}
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Activity Name</label>
                <input
                  type="text"
                  value={blockForm.activityName}
                  onChange={(e) => setBlockForm((prev) => ({ ...prev, activityName: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Block Type</label>
                <select
                  value={blockForm.type}
                  onChange={(e) => setBlockForm((prev) => ({ ...prev, type: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                >
                  {Object.entries(BLOCK_TYPES).map(([key, value]) => (
                    <option key={key} value={key}>
                      {value.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Start Time</label>
                <input
                  type="time"
                  value={blockForm.startTime}
                  onChange={(e) => setBlockForm((prev) => ({ ...prev, startTime: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Duration (minutes)</label>
                <input
                  type="number"
                  value={blockForm.duration}
                  onChange={(e) =>
                    setBlockForm((prev) => ({ ...prev, duration: Number.parseInt(e.target.value) || 0 }))
                  }
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  min="15"
                  step="15"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Progress: {blockForm.progress}%</label>
                <input
                  type="range"
                  value={blockForm.progress}
                  onChange={(e) => setBlockForm((prev) => ({ ...prev, progress: Number.parseInt(e.target.value) }))}
                  className="w-full accent-[#84A98C]"
                  min="0"
                  max="100"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Recurrence</label>
                <select
                  value={blockForm.recurrence}
                  onChange={(e) => setBlockForm((prev) => ({ ...prev, recurrence: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                >
                  <option value="none">None</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="weekdays">Weekdays</option>
                  <option value="weekends">Weekends</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Potential Zone Delay</label>
                <select
                  value={blockForm.zoneDelay}
                  onChange={(e) => setBlockForm((prev) => ({ ...prev, zoneDelay: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                >
                  <option value="">None identified</option>
                  {FIVE_ZONE_DELAYS.map((zone) => (
                    <option key={zone.zone} value={zone.zone}>
                      {zone.zone}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">Assigned Core Tool</label>
                <select
                  value={blockForm.coreToolUsed}
                  onChange={(e) => setBlockForm((prev) => ({ ...prev, coreToolUsed: e.target.value }))}
                  className="w-full bg-white border border-gray-300 rounded-md px-3 py-2 text-gray-700 focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                >
                  <option value="">No tool assigned</option>
                  {coreThreeBlueprint?.coreTools.map((tool) => (
                    <option key={tool.name} value={tool.name}>
                      {tool.name}
                    </option>
                  )) || []}
                  <option value="2-Minute Bridge">2-Minute Bridge</option>
                  <option value="First Aid Kit">First Aid Kit</option>
                </select>
              </div>
            </div>

            <div className="mt-4">
              <div className="flex justify-between items-center mb-2">
                <label className="block text-sm font-medium text-gray-600">AI Generated Subtasks</label>
                <button
                  onClick={generateAISubtasks}
                  className="text-sm bg-[#84A98C] hover:bg-[#52796F] text-white font-bold py-1 px-3 rounded-md transition-colors"
                >
                  <i className="fas fa-magic mr-1"></i>Generate
                </button>
              </div>
              <textarea
                value={blockForm.subtasks}
                onChange={(e) => setBlockForm((prev) => ({ ...prev, subtasks: e.target.value }))}
                className="w-full bg-gray-50 border border-gray-300 rounded-md p-3 text-gray-700 text-sm font-mono focus:ring-1 focus:ring-[#84A98C] focus:border-[#84A98C]"
                rows={4}
                placeholder="Click 'Generate' to break down your task with personalization."
              />
            </div>

            <div className="mt-6 flex justify-end gap-3">
              <button
                onClick={() => {
                  setShowBlockModal(false)
                  setEditingBlock(null)
                  resetBlockForm()
                }}
                className="px-4 py-2 bg-gray-500 text-white rounded-md hover:bg-gray-600 transition-colors"
              >
                Cancel
              </button>
              {editingBlock && (
                <button
                  onClick={() => {
                    deleteScheduleBlock(editingBlock.id)
                    setShowBlockModal(false)
                    setEditingBlock(null)
                    resetBlockForm()
                  }}
                  className="px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-colors"
                >
                  Delete
                </button>
              )}
              <button
                onClick={editingBlock ? updateScheduleBlock : addScheduleBlock}
                className="px-4 py-2 bg-[#84A98C] text-white rounded-md hover:bg-[#52796F] transition-colors"
              >
                {editingBlock ? "Update" : "Save"} Integrated Block
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
