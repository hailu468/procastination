"use client"

import { useQuiz } from "@/contexts/quiz-context"
import { toolsData } from "@/lib/tools-data"
import ToolCard from "@/components/tool-card"

export default function ToolkitSection() {
  const { showToolkit, userType } = useQuiz()

  if (!showToolkit || !userType) {
    return null
  }

  const recommendedTools = {
    Perfectionist: ["uglyDraft", "resetRitual", "tinyStarts"],
    Avoider: ["nameEmotion", "twoMinBridge", "timeBlocking"],
    Overwhelmed: ["taskTriaging", "tinyStarts", "timeBlocking"],
    ImpulseSeeker: ["frictionEngineering", "focusSprints", "twoMinBridge"],
  }

  const recommended = recommendedTools[userType] || []

  return (
    <section id="toolkit" className="mb-16">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-[#354F52]">Your Neuro-Tailored Toolkit</h2>
        <p className="max-w-2xl mx-auto mt-2">
          Tools adapt to your progress, creating personalized challenges that rewire your brain
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(toolsData).map(([key, tool]) => (
          <ToolCard key={key} toolKey={key} tool={tool} isRecommended={recommended.includes(key)} />
        ))}
      </div>

      {/* Premium Teaser */}
      <div className="mt-12 p-8 text-center bg-gradient-to-r from-gray-50 to-blue-50 rounded-xl shadow-md border border-gray-200">
        <div className="mb-4">
          <i className="fas fa-lock text-4xl text-gray-400 mb-4"></i>
          <h3 className="text-2xl font-bold text-[#354F52] mb-2">Advanced Anti-Procrastination System</h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            Unlock the complete methodology from "You're Not Lazy" with advanced diagnostic tools, emergency
            interventions, and personalized system builders designed to rewire your brain for lasting change.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6 text-sm">
          <div className="bg-white p-3 rounded border border-gray-200">
            <i className="fas fa-search text-[#84A98C] mb-2"></i>
            <div className="font-semibold text-[#354F52]">5-Zone Diagnostic</div>
            <div className="text-gray-500">Precision targeting</div>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <i className="fas fa-first-aid text-red-500 mb-2"></i>
            <div className="font-semibold text-[#354F52]">Emergency Kit</div>
            <div className="text-gray-500">60-second interventions</div>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <i className="fas fa-bridge text-[#84A98C] mb-2"></i>
            <div className="font-semibold text-[#354F52]">2-Minute Bridge</div>
            <div className="text-gray-500">Micro-start breakthrough</div>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <i className="fas fa-tools text-[#84A98C] mb-2"></i>
            <div className="font-semibold text-[#354F52]">Core 3 Builder</div>
            <div className="text-gray-500">Personalized system</div>
          </div>
          <div className="bg-white p-3 rounded border border-gray-200">
            <i className="fas fa-calendar-week text-[#84A98C] mb-2"></i>
            <div className="font-semibold text-[#354F52]">7-Day Rewiring</div>
            <div className="text-gray-500">Neural pathway reconstruction</div>
          </div>
        </div>
        <p className="text-sm text-gray-500">Upgrade to Premium for the complete anti-procrastination methodology</p>
      </div>
    </section>
  )
}
