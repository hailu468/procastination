"use client"

import { useState } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { useToast } from "@/hooks/use-toast"

const AVAILABLE_TOOLS = [
  {
    name: "2-Minute Bridge",
    description: "Bypass resistance with microscopic starts that create momentum",
    bestFor: ["Avoider", "Overwhelmed"],
    category: "Action",
  },
  {
    name: "Chaos Draft",
    description: "Permission to create terrible first versions that defeat perfectionism",
    bestFor: ["Perfectionist"],
    category: "Mindset",
  },
  {
    name: "Emotion Shield Detector",
    description: "Identify what feeling you're avoiding to disarm procrastination's power",
    bestFor: ["Avoider", "Overwhelmed"],
    category: "Mindset",
  },
  {
    name: "Friction Engineering",
    description: "Make focus effortless and distraction exhausting through environment design",
    bestFor: ["ImpulseSeeker"],
    category: "Environment",
  },
  {
    name: "3-Step Reset Ritual",
    description: "Bounce back from setbacks in 3 minutes without guilt or shame spirals",
    bestFor: ["All"],
    category: "Recovery",
  },
  {
    name: "Time Anchoring",
    description: "Make time physical reality - if it's not blocked, it doesn't exist",
    bestFor: ["Overwhelmed", "ImpulseSeeker"],
    category: "Structure",
  },
  {
    name: "Focus Sprints",
    description: "Work with your brain's natural attention cycles, not against them",
    bestFor: ["ImpulseSeeker", "Overwhelmed"],
    category: "Behavior",
  },
  {
    name: "Safe Starts",
    description: "Break scary tasks into micro-actions so tiny they feel harmless",
    bestFor: ["Avoider"],
    category: "Action",
  },
]

export default function CoreThreeSelector() {
  const { userType } = useQuiz()
  const { showToast } = useToast()
  const [coreThree, setCoreThree] = useState<string[]>([])
  const [deploymentStrategy, setDeploymentStrategy] = useState("")
  const [blueprint, setBlueprint] = useState<any>(null)

  const handleToolToggle = (toolName: string) => {
    setCoreThree((prev) => {
      if (prev.includes(toolName)) {
        return prev.filter((t) => t !== toolName)
      } else if (prev.length < 3) {
        return [...prev, toolName]
      } else {
        showToast("You can only select 3 core tools. Remove one first.", true)
        return prev
      }
    })
  }

  const generateBlueprint = () => {
    if (coreThree.length !== 3) {
      showToast("Please select exactly 3 core tools", true)
      return
    }

    if (!deploymentStrategy.trim()) {
      showToast("Please describe when you'll deploy these tools", true)
      return
    }

    const selectedTools = AVAILABLE_TOOLS.filter((tool) => coreThree.includes(tool.name))

    setBlueprint({
      archetype: userType,
      coreTools: selectedTools,
      deploymentStrategy,
      createdAt: new Date().toISOString(),
    })

    showToast("Your Core 3 Blueprint is ready!")
  }

  const getRecommendedTools = () => {
    return AVAILABLE_TOOLS.filter((tool) => tool.bestFor.includes(userType) || tool.bestFor.includes("All"))
  }

  const isRecommended = (toolName: string) => {
    return getRecommendedTools().some((tool) => tool.name === toolName)
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <h3 className="text-2xl font-bold text-[#354F52] mb-4 flex items-center">
        <i className="fas fa-tools text-[#84A98C] mr-3"></i>
        Core 3 System Builder
      </h3>
      <p className="text-gray-600 mb-6">
        Choose your "Core Three" - the tools that feel most intuitive and effective for your {userType} type. Quality
        over quantity: 3 tools used consistently beats 10 tools used sporadically.
      </p>

      {/* Recommended Tools Section */}
      <div className="mb-6 p-4 bg-green-50 rounded-lg border border-green-200">
        <h4 className="font-semibold text-[#354F52] mb-2 flex items-center">
          <i className="fas fa-star text-yellow-500 mr-2"></i>
          Recommended for {userType} Types:
        </h4>
        <div className="text-sm text-green-700">
          {getRecommendedTools()
            .map((tool) => tool.name)
            .join(", ")}
        </div>
      </div>

      {/* Tool Selection Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        {AVAILABLE_TOOLS.map((tool) => (
          <div
            key={tool.name}
            className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
              coreThree.includes(tool.name)
                ? "border-[#84A98C] bg-green-50 shadow-md"
                : isRecommended(tool.name)
                  ? "border-yellow-300 bg-yellow-50 hover:border-[#84A98C]"
                  : "border-gray-200 hover:border-[#84A98C]"
            }`}
            onClick={() => handleToolToggle(tool.name)}
          >
            <div className="flex justify-between items-start mb-2">
              <h5 className="font-bold text-[#354F52]">{tool.name}</h5>
              <div className="flex gap-1">
                {isRecommended(tool.name) && <i className="fas fa-star text-yellow-500 text-sm"></i>}
                {coreThree.includes(tool.name) && <i className="fas fa-check-circle text-[#84A98C] text-sm"></i>}
              </div>
            </div>
            <p className="text-sm text-gray-600 mb-2">{tool.description}</p>
            <div className="flex justify-between items-center">
              <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">{tool.category}</span>
              <span className="text-xs text-gray-500">Best for: {tool.bestFor.join(", ")}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Selected Tools Counter */}
      <div className="mb-4 text-center">
        <span className={`text-lg font-semibold ${coreThree.length === 3 ? "text-green-600" : "text-gray-600"}`}>
          Selected: {coreThree.length}/3 Tools
        </span>
      </div>

      {/* Deployment Strategy */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          When will you deploy these tools? (Be specific)
        </label>
        <textarea
          value={deploymentStrategy}
          onChange={(e) => setDeploymentStrategy(e.target.value)}
          placeholder="e.g., 1. During my Sunday planning session, 2. Every morning before I start work, 3. The moment I feel myself shutting down"
          rows={4}
          className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
        />
      </div>

      <button
        onClick={generateBlueprint}
        className="w-full bg-[#84A98C] hover:bg-[#52796F] text-white font-semibold py-3 px-6 rounded-lg transition-colors"
      >
        <i className="fas fa-blueprint mr-2"></i>
        Generate My Core 3 Blueprint
      </button>

      {/* Blueprint Results */}
      {blueprint && (
        <div className="mt-6 p-6 bg-blue-50 border-l-4 border-[#84A98C] rounded-lg">
          <h4 className="text-xl font-bold text-[#354F52] mb-4">Your Personalized Core 3 Blueprint</h4>

          <div className="space-y-3">
            <p className="text-sm">
              <strong>Your Archetype:</strong> {blueprint.archetype}
            </p>

            <div>
              <strong className="text-sm">Your Core Three Tools:</strong>
              <ul className="list-disc list-inside ml-4 mt-1">
                {blueprint.coreTools.map((tool: any, index: number) => (
                  <li key={index} className="text-sm text-gray-700">
                    <strong>{tool.name}</strong> - {tool.description}
                  </li>
                ))}
              </ul>
            </div>

            <p className="text-sm">
              <strong>Deployment Strategy:</strong> {blueprint.deploymentStrategy}
            </p>

            <div className="text-xs text-gray-500 mt-4">
              Blueprint created: {new Date(blueprint.createdAt).toLocaleString()}
            </div>
          </div>
        </div>
      )}

      <div className="mt-4 text-center">
        <p className="text-sm text-gray-500 italic">
          Make it yours. Use what works for you and unapologetically discard what doesn't.
        </p>
      </div>
    </div>
  )
}
