"use client"

import { useState, useEffect, useRef } from "react"
import { useToast } from "@/hooks/use-toast"

export default function TwoMinuteBridge() {
  const [timerRunning, setTimerRunning] = useState(false)
  const [timeLeft, setTimeLeft] = useState(2 * 60) // 2 minutes in seconds
  const [currentTask, setCurrentTask] = useState("")
  const [message, setMessage] = useState("")
  const [completedSessions, setCompletedSessions] = useState(0)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const { showToast } = useToast()

  useEffect(() => {
    if (timerRunning && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft((prevTime) => prevTime - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      clearInterval(intervalRef.current!)
      setTimerRunning(false)
      setCompletedSessions((prev) => prev + 1)
      setMessage("Time's up! You have full permission to stop. But observe what has shifted...")
      showToast("2-Minute Bridge complete! Notice how the dread has likely shrunk.")
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
  }, [timerRunning, timeLeft, showToast])

  const startBridge = () => {
    if (!currentTask.trim()) {
      showToast("Please enter the task you're avoiding first", true)
      return
    }

    setTimeLeft(2 * 60)
    setMessage("Focus on the smallest, most specific, physically achievable first step.")
    setTimerRunning(true)
    showToast("2-Minute Bridge started! Just focus on the tiniest first step.")
  }

  const stopBridge = () => {
    if (intervalRef.current) clearInterval(intervalRef.current)
    setTimerRunning(false)
    setTimeLeft(2 * 60)
    setMessage("")
  }

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60)
    const remainingSeconds = seconds % 60
    return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`
  }

  const examples = [
    { task: "Exercise", wrong: "Go to the gym", right: "Put on workout socks" },
    { task: "Taxes", wrong: "Do my taxes", right: "Open the receipts file" },
    { task: "Report", wrong: "Write the report", right: "Type one bad sentence" },
  ]

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <h3 className="text-2xl font-bold text-[#354F52] mb-4 flex items-center">
        <i className="fas fa-bridge text-[#84A98C] mr-3"></i>
        2-Minute Bridge Focus
      </h3>
      <p className="text-gray-600 mb-4">
        Action begets motivation, not the other way around. This stealth maneuver bypasses your brain's natural
        defenses.
      </p>

      {/* Examples */}
      <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h4 className="font-semibold text-[#354F52] mb-3">Examples of Micro-Steps:</h4>
        <div className="space-y-2">
          {examples.map((example, index) => (
            <div key={index} className="text-sm">
              <span className="font-medium">{example.task}:</span>
              <span className="text-red-600 line-through ml-2">{example.wrong}</span>
              <span className="text-green-600 ml-2">→ {example.right}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="space-y-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">What task are you avoiding?</label>
          <input
            type="text"
            value={currentTask}
            onChange={(e) => setCurrentTask(e.target.value)}
            placeholder="e.g., Writing the quarterly report"
            className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
            disabled={timerRunning}
          />
        </div>
      </div>

      <div className="text-center mb-6">
        <div className="text-6xl font-bold text-[#84A98C] mb-4">{formatTime(timeLeft)}</div>

        {message && <p className="text-lg text-gray-700 mb-4 font-medium">{message}</p>}

        <div className="flex justify-center gap-4">
          <button
            onClick={startBridge}
            disabled={timerRunning}
            className={`px-6 py-3 rounded-lg font-semibold transition-colors ${
              timerRunning
                ? "bg-gray-400 text-gray-600 cursor-not-allowed"
                : "bg-[#84A98C] hover:bg-[#52796F] text-white"
            }`}
          >
            {timerRunning ? "Bridge Running..." : "Start 2-Minute Bridge"}
          </button>

          {timerRunning && (
            <button
              onClick={stopBridge}
              className="px-6 py-3 bg-red-500 hover:bg-red-600 text-white rounded-lg font-semibold transition-colors"
            >
              Stop Bridge
            </button>
          )}
        </div>
      </div>

      {completedSessions > 0 && (
        <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
          <p className="text-green-700 font-semibold">🎉 Bridges Completed: {completedSessions}</p>
          <p className="text-sm text-green-600 mt-1">Each micro-start rewires your brain for action over avoidance</p>
        </div>
      )}

      <div className="mt-4 text-center">
        <p className="text-sm text-gray-500 italic">
          Execute only the micro-step. When the timer goes off, you have full permission to stop. But observe what has
          shifted - the dread has likely shrunk.
        </p>
      </div>
    </div>
  )
}
