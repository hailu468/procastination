"use client"

import { useState } from "react"

export default function ProgressRings() {
  const [consistency, setConsistency] = useState(30)
  const [mastery, setMastery] = useState(45)
  const [resilience, setResilience] = useState(60)

  const circumference = 2 * Math.PI * 40

  const ProgressRing = ({ value, label }: { value: number; label: string }) => {
    const offset = circumference - (value / 100) * circumference

    return (
      <div className="text-center">
        <div className="mx-auto w-24 h-24 relative">
          <svg className="w-full h-full transform -rotate-90" viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="40" stroke="#CAD2C5" strokeWidth="8" fill="none" />
            <circle
              cx="50"
              cy="50"
              r="40"
              stroke="#84A98C"
              strokeWidth="8"
              fill="none"
              strokeLinecap="round"
              strokeDasharray={circumference}
              strokeDashoffset={offset}
              className="transition-all duration-1000"
            />
          </svg>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
            <span className="text-2xl font-bold text-[#84A98C]">{value}%</span>
          </div>
        </div>
        <p className="mt-2 font-medium">{label}</p>
      </div>
    )
  }

  return (
    <div className="mt-8">
      <h3 className="text-xl font-bold text-[#52796F] mb-4">Neuro Progress Tracker</h3>
      <div className="grid grid-cols-3 gap-4">
        <ProgressRing value={consistency} label="Consistency" />
        <ProgressRing value={mastery} label="Mastery" />
        <ProgressRing value={resilience} label="Resilience" />
      </div>
    </div>
  )
}
