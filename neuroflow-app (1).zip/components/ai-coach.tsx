"use client"

import { useState } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { callGeminiAPI } from "@/lib/gemini-api"
import { toolsData } from "@/lib/tools-data"

export default function AICoach() {
  const { isPremiumUnlocked, userType, selectedSystemTools } = useQuiz()
  const [guidance, setGuidance] = useState<string>("")
  const [loading, setLoading] = useState(false)

  const getAIGuidance = async () => {
    if (!isPremiumUnlocked || !userType) return

    setLoading(true)
    const selectedToolNames =
      Array.from(selectedSystemTools)
        .map((key) => toolsData[key].name)
        .join(", ") || "No tools selected yet."

    const prompt = `As an AI Coach for a user with the primary procrastination type "${userType}", who has selected the following tools: ${selectedToolNames}. Provide a concise, actionable, and encouraging daily guidance message (2-3 sentences max). Focus on a micro-strategy for today.`

    try {
      const result = await callGeminiAPI(prompt)
      setGuidance(result || "Failed to get AI guidance. Please try again.")
    } catch (error) {
      setGuidance("Failed to get AI guidance. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className={`p-4 bg-gray-50 rounded-md relative ${!isPremiumUnlocked ? "opacity-75" : ""}`}>
      <h4 className="font-bold mb-2">AI Coach</h4>
      <p className="text-sm mb-3">
        {guidance ||
          (isPremiumUnlocked
            ? "Your personalized AI Coach is ready!"
            : "Get personalized guidance based on your progress")}
      </p>
      <button
        onClick={getAIGuidance}
        disabled={!isPremiumUnlocked || loading}
        className={`w-full px-4 py-2 rounded-lg text-sm ${
          isPremiumUnlocked
            ? "bg-[#84A98C] text-white hover:bg-[#52796F]"
            : "bg-gray-200 text-gray-500 cursor-not-allowed"
        }`}
      >
        {loading ? "Generating..." : isPremiumUnlocked ? "Get AI Guidance ✨" : "Unlock Premium"}
      </button>
      {!isPremiumUnlocked && (
        <span className="absolute top-2 right-2 bg-[#354F52] text-white text-xs font-bold px-2 py-1 rounded">
          PREMIUM
        </span>
      )}
    </div>
  )
}
