export default function IntroSection() {
  return (
    <section className="text-center mb-16 animate-fade-in">
      <h1 className="text-4xl md:text-5xl font-bold text-[#354F52] mb-4">Your Brain's Anti-Procrastination OS</h1>
      <p className="max-w-3xl mx-auto text-lg">
        Stop fighting willpower battles. NeuroFlow diagnoses your unique procrastination patterns and builds
        personalized systems that make progress inevitable.
      </p>
      <div className="mt-8 max-w-2xl mx-auto bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-xl shadow-inner">
        <div className="text-sm font-semibold text-[#84A98C] mb-2">HOW IT WORKS</div>
        <div className="grid grid-cols-3 gap-4">
          <div className="p-4">
            <div className="text-2xl text-[#84A98C] mb-2">1</div>
            <h3 className="font-bold">Diagnose</h3>
            <p className="text-sm mt-2">AI-powered analysis of your procrastination fingerprint</p>
          </div>
          <div className="p-4">
            <div className="text-2xl text-[#84A98C] mb-2">2</div>
            <h3 className="font-bold">Prescribe</h3>
            <p className="text-sm mt-2">Personalized tools matching your brain's wiring</p>
          </div>
          <div className="p-4">
            <div className="text-2xl text-[#84A98C] mb-2">3</div>
            <h3 className="font-bold">Transform</h3>
            <p className="text-sm mt-2">Adaptive systems that evolve with your progress</p>
          </div>
        </div>
        <div className="mt-4 text-xs text-gray-600">
          <i className="fas fa-info-circle mr-1"></i>
          You can restart your diagnosis anytime using the "Back to Diagnosis" button in the header
        </div>
      </div>
    </section>
  )
}
