"use client"

import { useState } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { useToast } from "@/hooks/use-toast"

const NEURO_KICKSTART_DAYS = [
  {
    day: 1,
    focus: "Awareness",
    title: "Decode Your Delay Pattern",
    action:
      "Identify one task you are avoiding. Name the specific emotion that is triggering your delay (e.g., 'I am avoiding the feeling of confusion').",
    neuralTarget: "Prefrontal cortex awareness",
    tool: "Emotion Shield Detector",
  },
  {
    day: 2,
    focus: "Tiny Start Mastery",
    title: "The 2-Minute Breakthrough",
    action:
      "Choose that same avoided task and perform a single 2-minute ignition action. Focus purely on the start, not on completion.",
    neuralTarget: "Action initiation pathways",
    tool: "2-Minute Bridge",
  },
  {
    day: 3,
    focus: "Friction Fix",
    title: "Environment Engineering",
    action:
      "Make one common distraction harder to access (e.g., move your phone). Make your priority task easier to start (e.g., open the file first thing).",
    neuralTarget: "Environmental conditioning",
    tool: "Friction Engineering",
  },
  {
    day: 4,
    focus: "Time Anchor",
    title: "Calendar Commitment",
    action: "Schedule a 25-minute, non-negotiable time block for your priority task in tomorrow's calendar.",
    neuralTarget: "Temporal binding circuits",
    tool: "Time Anchoring",
  },
  {
    day: 5,
    focus: "Reset Mastery",
    title: "Shame-Proof Recovery",
    action:
      "At the first sign of self-criticism or after a minor slip-up, immediately practice the 3-Minute Redemption Ritual.",
    neuralTarget: "Recovery resilience",
    tool: "3-Step Reset Ritual",
  },
  {
    day: 6,
    focus: "Personalize",
    title: "Core 3 Selection",
    action: "Formally write down your 'Core Three' tools. Decide when and how you will use one of them tomorrow.",
    neuralTarget: "System integration",
    tool: "Core 3 Selector",
  },
  {
    day: 7,
    focus: "Integrate & Plan",
    title: "Neural Architecture Review",
    action:
      "Review your progress from the week. Use your custom blueprint to plan your top 3 priorities for the upcoming week.",
    neuralTarget: "Long-term pathway consolidation",
    tool: "System Blueprint",
  },
]

export default function EnhancedSevenDayProgram() {
  const { userType } = useQuiz()
  const { showToast } = useToast()
  const [completedDays, setCompletedDays] = useState<boolean[]>(Array(7).fill(false))
  const [dailyReflections, setDailyReflections] = useState<string[]>(Array(7).fill(""))
  const [currentDay, setCurrentDay] = useState(1)

  const handleDayComplete = (dayIndex: number) => {
    const newCompleted = [...completedDays]
    newCompleted[dayIndex] = !newCompleted[dayIndex]
    setCompletedDays(newCompleted)

    if (newCompleted[dayIndex]) {
      showToast(`Day ${dayIndex + 1} completed! Neural pathways strengthening.`)
      if (dayIndex + 1 < 7) {
        setCurrentDay(dayIndex + 2)
      }
    }
  }

  const handleReflectionChange = (dayIndex: number, reflection: string) => {
    const newReflections = [...dailyReflections]
    newReflections[dayIndex] = reflection
    setDailyReflections(newReflections)
  }

  const getCompletionRate = () => {
    const completed = completedDays.filter(Boolean).length
    return Math.round((completed / 7) * 100)
  }

  const getPersonalizedTip = (day: any) => {
    const tips = {
      Perfectionist: {
        1: "Focus on naming the fear of 'not being good enough' - this is your core emotional trigger.",
        2: "Your 2-minute action should be intentionally imperfect. Embrace the chaos draft mentality.",
        3: "Remove perfectionist triggers: close extra research tabs, set a 'good enough' timer.",
        4: "Schedule 'draft time' not 'perfect time' - lower the stakes in your calendar language.",
        5: "Your reset phrase: 'Progress over perfection' - perfectionism is the enemy of done.",
        6: "Choose tools that embrace imperfection: Chaos Draft, 2-Minute Bridge, Reset Ritual.",
        7: "Plan with 80% completion as success - perfectionism kills momentum.",
      },
      Avoider: {
        1: "Name the specific discomfort you're avoiding - usually fear of judgment or failure.",
        2: "Make your 2-minute action feel completely safe - no judgment, no stakes.",
        3: "Create a 'safe space' for work - remove anything that triggers avoidance anxiety.",
        4: "Schedule tasks during your highest energy time when avoidance is weakest.",
        5: "Your reset phrase: 'This is just practice' - remove the threat from the task.",
        6: "Choose tools that feel safe: Safe Starts, Emotion Detector, Time Anchoring.",
        7: "Plan with emotional safety first - what makes each task feel less threatening?",
      },
      Overwhelmed: {
        1: "Name the feeling of 'too much' - this paralysis is your brain's protection mechanism.",
        2: "Your 2-minute action should be the tiniest possible step - break it down further.",
        3: "Simplify your environment - one task, one screen, one focus point.",
        4: "Schedule one thing at a time - multiple time blocks create more overwhelm.",
        5: "Your reset phrase: 'One thing at a time' - complexity is the enemy of action.",
        6: "Choose tools that simplify: 2-Minute Bridge, Time Anchoring, Focus Sprints.",
        7: "Plan with simplicity - maximum 3 priorities, everything else is noise.",
      },
      ImpulseSeeker: {
        1: "Name the feeling of 'boredom' or 'restlessness' - your brain craves novelty.",
        2: "Make your 2-minute action novel or gamified - add an element of interest.",
        3: "Engineer friction for distractions, ease for focus - make boring tasks more accessible.",
        4: "Schedule variety - alternate task types to maintain interest.",
        5: "Your reset phrase: 'New attempt, new energy' - reframe setbacks as fresh starts.",
        6: "Choose tools that add variety: Focus Sprints, Friction Engineering, Reset Ritual.",
        7: "Plan with novelty - how can you make routine tasks feel fresh?",
      },
    }

    return (
      tips[userType as keyof typeof tips]?.[day.day as keyof (typeof tips)[typeof userType]] ||
      "Focus on building consistency over perfection."
    )
  }

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg border border-gray-200">
      <h3 className="text-2xl font-bold text-[#354F52] mb-4 flex items-center">
        <i className="fas fa-calendar-week text-[#84A98C] mr-3"></i>
        7-Day Neuro-Rewiring Program
      </h3>

      <div className="mb-6 p-4 bg-gradient-to-r from-[#CAD2C5] to-[#84A98C] rounded-lg text-white">
        <div className="flex justify-between items-center mb-2">
          <h4 className="text-lg font-bold">Your Neural Rewiring Progress</h4>
          <span className="text-2xl font-bold">{getCompletionRate()}%</span>
        </div>
        <div className="w-full bg-white/30 rounded-full h-3">
          <div
            className="h-full bg-white rounded-full transition-all duration-500"
            style={{ width: `${getCompletionRate()}%` }}
          />
        </div>
        <p className="text-sm mt-2 opacity-90">
          Systematic neural pathway reconstruction through targeted daily challenges
        </p>
      </div>

      <div className="space-y-4">
        {NEURO_KICKSTART_DAYS.map((day, index) => (
          <div
            key={index}
            className={`p-4 border-2 rounded-lg transition-all duration-300 ${
              completedDays[index]
                ? "border-green-500 bg-green-50 shadow-md"
                : currentDay === day.day
                  ? "border-[#84A98C] bg-blue-50 shadow-md"
                  : "border-gray-200 hover:border-[#84A98C]"
            }`}
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex-1">
                <div className="flex items-center gap-3 mb-2">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold ${
                      completedDays[index] ? "bg-green-500" : currentDay === day.day ? "bg-[#84A98C]" : "bg-gray-400"
                    }`}
                  >
                    {completedDays[index] ? "✓" : day.day}
                  </div>
                  <div>
                    <h4 className="text-lg font-bold text-[#354F52]">
                      Day {day.day}: {day.title}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {day.focus} • {day.neuralTarget}
                    </p>
                  </div>
                </div>

                <p className="text-gray-700 mb-3">{day.action}</p>

                {/* Personalized Tip */}
                <div className="p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded mb-3">
                  <p className="text-sm text-yellow-800">
                    <strong>For {userType} Types:</strong> {getPersonalizedTip(day)}
                  </p>
                </div>

                {/* Daily Reflection */}
                <div className="mb-3">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Daily Reflection (optional):</label>
                  <textarea
                    value={dailyReflections[index]}
                    onChange={(e) => handleReflectionChange(index, e.target.value)}
                    placeholder="How did this day's challenge feel? What did you learn?"
                    rows={2}
                    className="w-full p-2 text-sm border border-gray-300 rounded focus:ring-2 focus:ring-[#84A98C] focus:border-[#84A98C]"
                  />
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <span className="text-sm bg-gray-100 text-gray-600 px-2 py-1 rounded">Tool: {day.tool}</span>
              <button
                onClick={() => handleDayComplete(index)}
                className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
                  completedDays[index]
                    ? "bg-green-500 hover:bg-green-600 text-white"
                    : "bg-[#84A98C] hover:bg-[#52796F] text-white"
                }`}
              >
                {completedDays[index] ? "✓ Completed" : "Mark Complete"}
              </button>
            </div>
          </div>
        ))}
      </div>

      {getCompletionRate() === 100 && (
        <div className="mt-6 p-6 bg-gradient-to-r from-green-50 to-blue-50 border border-green-200 rounded-lg text-center">
          <h4 className="text-xl font-bold text-green-700 mb-2">🎉 Neural Rewiring Complete!</h4>
          <p className="text-green-600 mb-4">
            You've successfully completed the 7-day program. Your brain has begun building new neural pathways for
            action over avoidance.
          </p>
          <p className="text-sm text-gray-600">
            This week wasn't just a test run - it's the beginning of a new way of operating. Continue using your Core 3
            tools to maintain momentum.
          </p>
        </div>
      )}

      <div className="mt-6 text-center">
        <p className="text-sm text-gray-500 italic">
          Your brain rewires itself faster through small, consistent daily actions than through infrequent, heroic
          efforts.
        </p>
      </div>
    </div>
  )
}
