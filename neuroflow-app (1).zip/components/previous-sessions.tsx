"use client"

import { useState, useEffect } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { useToast } from "@/hooks/use-toast"

interface PreviousSession {
  userType: string
  selectedSystemTools: string[]
  isPremiumUnlocked: boolean
  timestamp: string
}

export default function PreviousSessions() {
  const [previousSessions, setPreviousSessions] = useState<PreviousSession[]>([])
  const [showSessions, setShowSessions] = useState(false)
  const {
    setUserType,
    setShowResult,
    setShowToolkit,
    setSelectedSystemTools,
    setCurrentQuestionIndex,
    setSelectedAnswers,
  } = useQuiz()
  const { showToast } = useToast()

  useEffect(() => {
    const sessions = JSON.parse(localStorage.getItem("neuroflow-previous-sessions") || "[]")
    setPreviousSessions(sessions)
  }, [])

  const restoreSession = (session: PreviousSession) => {
    // Restore the previous session state
    setUserType(session.userType)
    setShowResult(true)
    setShowToolkit(true)
    setSelectedSystemTools(new Set(session.selectedSystemTools))
    setCurrentQuestionIndex(0) // Reset quiz to completed state
    setSelectedAnswers([]) // Clear quiz answers since we're restoring results

    setShowSessions(false)
    showToast(`Restored session: ${session.userType} type`)

    // Scroll to toolkit section
    setTimeout(() => {
      document.getElementById("toolkit")?.scrollIntoView({ behavior: "smooth" })
    }, 100)
  }

  const clearSession = (index: number) => {
    const updatedSessions = previousSessions.filter((_, i) => i !== index)
    setPreviousSessions(updatedSessions)
    localStorage.setItem("neuroflow-previous-sessions", JSON.stringify(updatedSessions))
    showToast("Session deleted")
  }

  const clearAllSessions = () => {
    setPreviousSessions([])
    localStorage.removeItem("neuroflow-previous-sessions")
    showToast("All previous sessions cleared")
  }

  if (previousSessions.length === 0) {
    return null
  }

  return (
    <div className="mb-6">
      <button
        onClick={() => setShowSessions(!showSessions)}
        className="text-sm text-[#84A98C] hover:text-[#52796F] font-medium flex items-center gap-2"
      >
        <i className="fas fa-history"></i>
        Previous Sessions ({previousSessions.length})
        <i className={`fas fa-chevron-${showSessions ? "up" : "down"} text-xs`}></i>
      </button>

      {showSessions && (
        <div className="mt-3 bg-gray-50 rounded-lg p-4 border border-gray-200">
          <div className="flex justify-between items-center mb-3">
            <h4 className="font-semibold text-[#354F52]">Restore Previous Session</h4>
            <button onClick={clearAllSessions} className="text-xs text-red-600 hover:text-red-800">
              Clear All
            </button>
          </div>

          <div className="space-y-2">
            {previousSessions.map((session, index) => (
              <div
                key={index}
                className="flex items-center justify-between bg-white p-3 rounded border border-gray-200 hover:border-[#84A98C] transition-colors"
              >
                <div className="flex-1">
                  <div className="font-medium text-[#354F52]">
                    {session.userType === "Perfectionist" && "🧠 The Precision Architect"}
                    {session.userType === "Avoider" && "🛡️ The Discomfort Dodger"}
                    {session.userType === "Overwhelmed" && "🌀 The Decision Paralysis Victim"}
                    {session.userType === "ImpulseSeeker" && "⚡ The Novelty Chaser"}
                  </div>
                  <div className="text-sm text-gray-600">
                    {session.selectedSystemTools.length} tools selected
                    {session.isPremiumUnlocked && (
                      <span className="ml-2 text-xs bg-[#84A98C] text-white px-2 py-1 rounded">Premium</span>
                    )}
                  </div>
                  <div className="text-xs text-gray-500">
                    {new Date(session.timestamp).toLocaleDateString()} at{" "}
                    {new Date(session.timestamp).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => restoreSession(session)}
                    className="px-3 py-1 bg-[#84A98C] text-white text-sm rounded hover:bg-[#52796F] transition-colors"
                  >
                    Restore
                  </button>
                  <button
                    onClick={() => clearSession(index)}
                    className="px-2 py-1 text-gray-400 hover:text-red-600 transition-colors"
                  >
                    <i className="fas fa-trash text-xs"></i>
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-3 text-xs text-gray-500 text-center">
            Your progress is automatically saved when you start a new diagnosis
          </div>
        </div>
      )}
    </div>
  )
}
