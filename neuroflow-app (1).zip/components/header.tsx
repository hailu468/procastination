"use client"

import { useQuiz } from "@/contexts/quiz-context"

export default function Header() {
  const { isPremiumUnlocked, togglePremium, resetToBeginning } = useQuiz()

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <nav className="container mx-auto px-6 py-3 flex justify-between items-center">
        <div className="text-xl font-bold text-[#354F52] flex items-center">
          <span>Neuro</span>
          <span className="text-[#84A98C]">Flow</span>
          <span className="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded ml-2">BETA</span>
        </div>
        <div className="space-x-4">
          <button
            onClick={resetToBeginning}
            className="hover:text-[#84A98C] transition-colors text-sm"
            title="Start over with a new diagnosis"
          >
            <i className="fas fa-redo mr-1"></i>
            Back to Diagnosis
          </button>
          <a href="#diagnose" className="hover:text-[#84A98C] transition-colors">
            Diagnose
          </a>
          <a href="#toolkit" className="hover:text-[#84A98C] transition-colors">
            Toolkit
          </a>
          <a href="#system" className="hover:text-[#84A98C] transition-colors">
            My System
          </a>
          <button
            onClick={togglePremium}
            className={`px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
              isPremiumUnlocked
                ? "bg-[#84A98C] text-white cursor-default"
                : "bg-gray-200 text-[#354F52] hover:bg-gray-300"
            }`}
            disabled={isPremiumUnlocked}
          >
            {isPremiumUnlocked ? "Premium Unlocked" : "Unlock Premium"}
          </button>
        </div>
      </nav>
    </header>
  )
}
