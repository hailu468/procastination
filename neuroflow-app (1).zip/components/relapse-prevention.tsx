"use client"

import { useState } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { callGeminiAPI } from "@/lib/gemini-api"

export default function RelapsePrevention() {
  const { userType } = useQuiz()
  const [strategy, setStrategy] = useState<string>("")
  const [loading, setLoading] = useState(false)

  const activatePrevention = async () => {
    if (!userType) return

    setLoading(true)
    const prompt = `Based on a user with procrastination type "${userType}" and a predicted high-risk time of 2-4 PM, provide one concise, actionable strategy to prevent a relapse. Be direct and practical.`

    try {
      const result = await callGeminiAPI(prompt)
      setStrategy(result || "Failed to generate strategy. Please try again.")
    } catch (error) {
      setStrategy("Failed to generate strategy. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="p-4 bg-gray-50 rounded-md">
      <h4 className="font-bold mb-2">Relapse Prevention</h4>
      <div className="text-sm">
        <p className="mb-2">
          Your high-risk time: <span className="font-semibold">2-4 PM</span>
        </p>
        <button
          onClick={activatePrevention}
          disabled={loading}
          className="w-full px-4 py-2 bg-[#84A98C] text-white rounded-lg text-sm hover:bg-[#52796F] disabled:opacity-50"
        >
          {loading ? "Generating Strategy..." : "Activate Prevention"}
        </button>
        {strategy && <div className="mt-3 p-3 bg-blue-50 rounded-md text-sm">✨ Strategy: {strategy}</div>}
      </div>
    </div>
  )
}
