"use client"

import { useState } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { toolsData } from "@/lib/tools-data"

export default function KickstartChallenge() {
  const { selectedSystemTools } = useQuiz()
  const [currentDay, setCurrentDay] = useState(1)

  const getCurrentChallenge = () => {
    const toolsArray = Array.from(selectedSystemTools)
    if (toolsArray.length === 0) return "Select tools to start your kickstart!"

    const currentToolKey = toolsArray[(currentDay - 1) % toolsArray.length]
    const tool = toolsData[currentToolKey]
    return `Focus on ${tool.name}`
  }

  const nextDay = () => {
    setCurrentDay((prev) => (prev % 7) + 1)
  }

  return (
    <div className="p-4 bg-gray-50 rounded-md">
      <div className="flex justify-between items-center">
        <h4 className="font-bold">Today's Challenge</h4>
        <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">Day {currentDay}/7</span>
      </div>
      <div className="mt-2 text-lg font-semibold text-[#84A98C]">{getCurrentChallenge()}</div>
      <div className="mt-4 flex justify-center">
        <button onClick={nextDay} className="px-4 py-2 bg-[#84A98C] text-white rounded-lg hover:bg-[#52796F]">
          Next Day
        </button>
      </div>
    </div>
  )
}
