"use client"

import { useState, useEffect } from "react"
import { useQuiz } from "@/contexts/quiz-context"
import { callGeminiAPI } from "@/lib/gemini-api"

interface NeuralAnalysisProps {
  userType: string
}

export default function NeuralAnalysis({ userType }: NeuralAnalysisProps) {
  const { isPremiumUnlocked } = useQuiz()
  const [relapseRisk, setRelapseRisk] = useState<number | null>(null)
  const [predictedTrigger, setPredictedTrigger] = useState<string>("")
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    runNeuralAnalysis()
  }, [userType])

  const runNeuralAnalysis = async () => {
    setLoading(true)

    const prompt = `Based on a user identified as a "${userType}" procrastination type, provide a relapse risk percentage (0-100) and a concise predicted trigger statement. Format the response as a JSON object with keys "relapseRisk" (number) and "predictedTrigger" (string).`

    const schema = {
      type: "OBJECT",
      properties: {
        relapseRisk: { type: "NUMBER" },
        predictedTrigger: { type: "STRING" },
      },
      required: ["relapseRisk", "predictedTrigger"],
    }

    try {
      const analysis = await callGeminiAPI(prompt, schema)
      if (analysis) {
        setRelapseRisk(analysis.relapseRisk)
        setPredictedTrigger(analysis.predictedTrigger)
      }
    } catch (error) {
      console.error("Neural analysis failed:", error)
      setRelapseRisk(null)
      setPredictedTrigger("Analysis failed. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto mt-8 bg-white p-8 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-bold text-[#52796F]">AI-Powered Neural Analysis</h3>
        {!isPremiumUnlocked && (
          <span className="bg-[#354F52] text-white text-xs font-bold px-2 py-1 rounded">PREMIUM</span>
        )}
      </div>

      <div className="grid grid-cols-2 gap-6">
        <div>
          <h4 className="font-bold mb-2">Your Neural Profile</h4>
          <div className="w-full h-48 bg-gray-50 rounded-lg flex items-center justify-center">
            <svg viewBox="0 0 300 200" className="w-full h-full">
              {/* Neural path visualization */}
              <path
                d="M20,50 Q50,30 80,50 T140,50"
                stroke="#84A98C"
                strokeWidth="2"
                fill="none"
                className="animate-pulse"
              />
              <path
                d="M20,70 Q50,40 80,70 T140,70"
                stroke="#84A98C"
                strokeWidth="2"
                fill="none"
                className="animate-pulse"
                style={{ animationDelay: "0.3s" }}
              />
              <path
                d="M20,90 Q50,60 80,90 T140,90"
                stroke="#84A98C"
                strokeWidth="2"
                fill="none"
                className="animate-pulse"
                style={{ animationDelay: "0.6s" }}
              />
            </svg>
          </div>
        </div>

        <div>
          <h4 className="font-bold mb-2">Behavior Prediction</h4>
          <div className="text-sm">
            <div className="flex justify-between mb-1">
              <span>Relapse Risk</span>
              <span>{loading ? "Calculating..." : `${relapseRisk}%`}</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
              <div
                className="bg-[#84A98C] h-2.5 rounded-full transition-all duration-1000"
                style={{ width: loading ? "0%" : `${relapseRisk}%` }}
              />
            </div>
            <p className="text-sm italic mt-4">{loading ? "Analyzing your patterns..." : `"${predictedTrigger}"`}</p>
          </div>
        </div>
      </div>
    </div>
  )
}
