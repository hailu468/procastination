import { NextResponse } from "next/server"

const GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

export async function POST(req: Request) {
  try {
    const { prompt, schema } = await req.json()

    if (!prompt) {
      return NextResponse.json({ error: "Missing prompt" }, { status: 400 })
    }

    const apiKey = process.env.GEMINI_API_KEY
    if (!apiKey) {
      return NextResponse.json({ error: "Missing GEMINI_API_KEY" }, { status: 500 })
    }

    const body: any = {
      contents: [{ role: "user", parts: [{ text: prompt }] }],
    }

    if (schema) {
      body.generationConfig = {
        responseMimeType: "application/json",
        responseSchema: schema,
      }
    }

    const geminiRes = await fetch(`${GEMINI_URL}?key=${apiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })

    const data = await geminiRes.json()

    if (data?.candidates?.[0]?.content?.parts?.[0]?.text) {
      const text = data.candidates[0].content.parts[0].text
      const parsed = schema ? JSON.parse(text) : text
      return NextResponse.json({ result: parsed })
    }

    return NextResponse.json({ error: "Unexpected Gemini response", raw: data }, { status: 502 })
  } catch (err) {
    console.error("Gemini route error:", err)
    return NextResponse.json({ error: "Server error" }, { status: 500 })
  }
}
