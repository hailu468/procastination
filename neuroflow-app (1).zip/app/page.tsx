"use client"

import { useState, useEffect } from "react"
import Header from "@/components/header"
import IntroSection from "@/components/intro-section"
import QuizSection from "@/components/quiz-section"
import ToolkitSection from "@/components/toolkit-section"
import SystemSection from "@/components/system-section"
import Toast from "@/components/toast"
import { QuizProvider } from "@/contexts/quiz-context"

export default function HomePage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <QuizProvider>
      <div className="min-h-screen bg-[#F8F7F2] text-gray-700">
        <Header />
        <main className="container mx-auto px-6 py-12">
          <IntroSection />
          <QuizSection />
          <ToolkitSection />
          <SystemSection />
        </main>
        <footer className="text-center py-8 border-t border-gray-200">
          <div className="container mx-auto px-6">
            <p className="text-gray-500 mb-2">NeuroFlow: Your Anti-Procrastination Operating System</p>
            <p className="text-sm text-gray-400">
              Based on the neuroscience principles from "The Anti-Procrastination Architecture"
            </p>
          </div>
        </footer>
        <Toast />
      </div>
    </QuizProvider>
  )
}
