import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ToastProvider } from "@/hooks/use-toast"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "NeuroFlow: Your Procrastination OS",
  description:
    "Stop fighting willpower battles. NeuroFlow diagnoses your unique procrastination patterns and builds personalized systems that make progress inevitable.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${inter.className} antialiased leading-relaxed`}>
        <ToastProvider>{children}</ToastProvider>
      </body>
    </html>
  )
}
