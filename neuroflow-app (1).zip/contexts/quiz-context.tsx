"use client"

import { createContext, useContext, useState, type ReactNode, useRef, useEffect } from "react"
import { useToast } from "@/hooks/use-toast"

interface QuizContextType {
  currentQuestionIndex: number
  selectedAnswers: string[]
  userType: string
  showResult: boolean
  showToolkit: boolean
  selectedSystemTools: Set<string>
  isPremiumUnlocked: boolean
  setCurrentQuestionIndex: (index: number) => void
  setSelectedAnswers: (answers: string[]) => void
  setUserType: (type: string) => void
  setShowResult: (show: boolean) => void
  setShowToolkit: (show: boolean) => void
  addToolToSystem: (toolKey: string) => void
  togglePremium: () => void
  resetToBeginning: () => void // Add this new function
}

const QuizContext = createContext<QuizContextType | undefined>(undefined)

export function QuizProvider({ children }: { children: ReactNode }) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<string[]>([])
  const [userType, setUserType] = useState("")
  const [showResult, setShowResult] = useState(false)
  const [showToolkit, setShowToolkit] = useState(false)
  const [selectedSystemTools, setSelectedSystemTools] = useState<Set<string>>(new Set())
  const [isPremiumUnlocked, setIsPremiumUnlocked] = useState(false)
  const { showToast } = useToast()
  const isFirstRender = useRef(true)

  const addToolToSystem = (toolKey: string) => {
    if (selectedSystemTools.has(toolKey)) return

    setSelectedSystemTools((prev) => new Set([...prev, toolKey]))
    showToast("Tool added to your system!")
  }

  const togglePremium = () => {
    setIsPremiumUnlocked((prev) => !prev)
  }

  // Show toast when premium status actually changes (skip first render)
  useEffect(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false
      return
    }
    // ❗️Do NOT add showToast to the dependency array or it will fire every render
    showToast(isPremiumUnlocked ? "Premium features unlocked!" : "Premium features locked.")
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPremiumUnlocked])

  const resetToBeginning = () => {
    // Save current progress to localStorage before resetting
    const currentProgress = {
      userType,
      selectedSystemTools: Array.from(selectedSystemTools),
      isPremiumUnlocked,
      timestamp: new Date().toISOString(),
    }

    // Store up to 3 previous sessions
    const previousSessions = JSON.parse(localStorage.getItem("neuroflow-previous-sessions") || "[]")
    previousSessions.unshift(currentProgress)
    if (previousSessions.length > 3) {
      previousSessions.pop()
    }
    localStorage.setItem("neuroflow-previous-sessions", JSON.stringify(previousSessions))

    // Reset to initial state
    setCurrentQuestionIndex(0)
    setSelectedAnswers([])
    setUserType("")
    setShowResult(false)
    setShowToolkit(false)
    setSelectedSystemTools(new Set())

    // Scroll to top and show toast
    window.scrollTo({ top: 0, behavior: "smooth" })
    showToast("Starting fresh! Your previous session has been saved.")
  }

  return (
    <QuizContext.Provider
      value={{
        currentQuestionIndex,
        selectedAnswers,
        userType,
        showResult,
        showToolkit,
        selectedSystemTools,
        isPremiumUnlocked,
        setCurrentQuestionIndex,
        setSelectedAnswers,
        setUserType,
        setShowResult,
        setShowToolkit,
        addToolToSystem,
        togglePremium,
        resetToBeginning, // Add this line
      }}
    >
      {children}
    </QuizContext.Provider>
  )
}

export function useQuiz() {
  const context = useContext(QuizContext)
  if (context === undefined) {
    throw new Error("useQuiz must be used within a QuizProvider")
  }
  return context
}
