export interface Tool {
  name: string
  description: string
  difficultyLevel: number
  challenges?: string[]
}

export const toolsData: Record<string, Tool> = {
  twoMinBridge: {
    name: "2-Minute Bridge",
    description: "Bypass resistance with microscopic starts that create momentum",
    difficultyLevel: 1,
    challenges: [
      "Open the file and type one word",
      "Set 120-second timer and start the worst version",
      "Do only the 2% version of your task",
    ],
  },
  uglyDraft: {
    name: "Ugly Draft Protocol",
    description: "Permission to create terrible first versions that defeat perfectionism",
    difficultyLevel: 1,
    challenges: [
      "Write the worst opening sentence possible",
      "Create a 5-minute terrible first draft",
      "Record a 30-second awful audio summary",
    ],
  },
  nameEmotion: {
    name: "Emotion Shield Detector",
    description: "Identify what feeling you're avoiding to disarm procrastination's power",
    difficultyLevel: 1,
  },
  frictionEngineering: {
    name: "Friction Engineering",
    description: "Make focus effortless and distraction exhausting through environment design",
    difficultyLevel: 1,
  },
  resetRitual: {
    name: "3-Step Reset Ritual",
    description: "Bounce back from setbacks in 3 minutes without guilt or shame spirals",
    difficultyLevel: 1,
  },
  timeBlocking: {
    name: "Time Visibility System",
    description: "Make time physical reality - if it's not blocked, it doesn't exist",
    difficultyLevel: 1,
  },
  taskTriaging: {
    name: "Zone 5 Triage",
    description: "Identify which of the 5 delay zones is sabotaging you right now",
    difficultyLevel: 1,
  },
  focusSprints: {
    name: "Neuro-Aligned Focus Sprints",
    description: "Work with your brain's natural attention cycles, not against them",
    difficultyLevel: 1,
  },
}

export const PROCRASTINATION_TYPES = [
  {
    type: "Perfectionist",
    fear: "Fear of imperfection",
    description: "Over-editing, false starts, endless research",
    motto: "If I can't do it perfectly, I won't do it at all.",
    neuralPattern: "Prefrontal overactivation - error detection system in overdrive",
  },
  {
    type: "Avoider",
    fear: "Fear of judgment/failure",
    description: "Distraction, busywork, emotional escape",
    motto: "If it feels uncomfortable, I'll do it later.",
    neuralPattern: "Amygdala hijack - threat detection system overactive",
  },
  {
    type: "Overwhelmed",
    fear: "Fear of wrong choices",
    description: "Freeze response, decision paralysis, tiny tasks only",
    motto: "There's so much to do, I don't know where to start.",
    neuralPattern: "Cognitive overload - decision-making circuits overwhelmed",
  },
  {
    type: "Impulse Seeker",
    fear: "Fear of boredom",
    description: "Novelty hopping, context switching, stimulation seeking",
    motto: "I'll do it, but only when I feel inspired.",
    neuralPattern: "Reward deficiency - dopamine system seeking constant stimulation",
  },
]
