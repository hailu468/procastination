/**
 * Client / Server helper – calls our internal `/api/gemini` route.
 * Keeps the real GEMINI_API_KEY on the server only.
 */
export async function callGeminiAPI(prompt: string, schema?: any) {
  try {
    const res = await fetch("/api/gemini", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ prompt, schema }),
    })

    const { result, error } = await res.json()
    if (error) throw new Error(error)
    return result
  } catch (err) {
    console.error("callGeminiAPI error:", err)
    return getMockResponse(prompt, schema)
  }
}

function getMockResponse(prompt: string, schema?: any) {
  // Mock responses for development/demo purposes
  if (schema && schema.properties?.relapseRisk) {
    return {
      relapseRisk: Math.floor(Math.random() * 40) + 30, // 30-70%
      predictedTrigger: "Your pattern shows high risk of avoidance during unstructured work blocks",
    }
  }

  if (prompt.includes("AI Coach")) {
    return "Focus on one tiny action today. Your brain builds momentum through small wins, not perfect plans."
  }

  if (prompt.includes("relapse prevention")) {
    return "Set a 2-minute timer and commit to just starting. The hardest part is beginning."
  }

  if (prompt.includes("emotional description")) {
    return "It sounds like you're experiencing anticipatory anxiety about potential failure or judgment."
  }

  return "This is a mock response. Please add your Gemini API key to enable AI features."
}
