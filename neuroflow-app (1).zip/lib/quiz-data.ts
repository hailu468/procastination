export const quizData = {
  questions: [
    {
      question: "When facing a big project, my first instinct is to...",
      options: [
        {
          text: "Plan every detail perfectly before starting",
          type: "Perfectionist",
          neural: "Prefrontal overactivation",
        },
        { text: "Find 'urgent' distractions like cleaning", type: "Avoider", neural: "Amygdala hijack" },
        { text: "Freeze, unsure where to begin", type: "Overwhelmed", neural: "Decision paralysis" },
        { text: "Get a new idea and switch to that", type: "ImpulseSeeker", neural: "Dopamine chasing" },
      ],
    },
    {
      question: "I stop working because...",
      options: [
        {
          text: "I worry the result won't be perfect",
          type: "Perfectionist",
          neural: "Error detection overactivation",
        },
        { text: "It feels uncomfortable or difficult", type: "Avoider", neural: "Discomfort intolerance" },
        { text: "I can't decide what to do next", type: "Overwhelmed", neural: "Cognitive overload" },
        { text: "Something more interesting grabs my attention", type: "ImpulseSeeker", neural: "Novelty seeking" },
      ],
    },
    {
      question: "My 'procrastination-fuel' is the fear of...",
      options: [
        { text: "Producing something flawed", type: "Perfectionist", neural: "Failure anticipation" },
        { text: "Being judged or failing", type: "Avoider", neural: "Social threat response" },
        { text: "Making the wrong choice", type: "Overwhelmed", neural: "Outcome uncertainty" },
        { text: "Being bored or constrained", type: "ImpulseSeeker", neural: "Reward deficiency" },
      ],
    },
  ],
  results: {
    Perfectionist: {
      title: "The Precision Architect",
      description:
        "Your prefrontal cortex demands perfection, creating paralysis through overanalysis. We'll build systems that lower stakes and embrace progress over polish.",
      icon: "🧠",
      neuralProfile: {
        prefrontal: 90,
        amygdala: 40,
        reward: 60,
        risk: "Overediting loops",
      },
      recommendedTools: ["uglyDraft", "resetRitual", "tinyStarts"],
    },
    Avoider: {
      title: "The Discomfort Dodger",
      description:
        "Your amygdala treats discomfort as threat, triggering escape behaviors. We'll rewire your response through graduated exposure and safety proofs.",
      icon: "🛡️",
      neuralProfile: {
        prefrontal: 50,
        amygdala: 85,
        reward: 40,
        risk: "Emotional avoidance spirals",
      },
      recommendedTools: ["nameEmotion", "twoMinBridge", "timeBlocking"],
    },
    Overwhelmed: {
      title: "The Decision Paralysis Victim",
      description:
        "Cognitive overload freezes your action circuits. We'll simplify choices and create clear entry points to bypass overwhelm.",
      icon: "🌀",
      neuralProfile: {
        prefrontal: 75,
        amygdala: 60,
        reward: 50,
        risk: "Task avoidance through paralysis",
      },
      recommendedTools: ["taskTriaging", "tinyStarts", "timeBlocking"],
    },
    ImpulseSeeker: {
      title: "The Novelty Chaser",
      description:
        "Your reward system craves dopamine hits, derailing focus. We'll engineer environments that make concentration more rewarding than distraction.",
      icon: "⚡",
      neuralProfile: {
        prefrontal: 40,
        amygdala: 50,
        reward: 90,
        risk: "Context switching fatigue",
      },
      recommendedTools: ["frictionEngineering", "focusSprints", "twoMinBridge"],
    },
  },
}
